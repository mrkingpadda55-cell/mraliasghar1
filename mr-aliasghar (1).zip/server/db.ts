import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  Wallet,
  TaskItem,
  TaskCompletion,
  SurveyItem,
  SurveyResponse,
  Transaction,
  Withdrawal,
  AppSettings,
  PaymentMethod,
  WithdrawalStatus,
} from '../src/types';

interface DatabaseSchema {
  users: (User & { passwordHash: string })[];
  wallets: Record<string, Wallet>;
  tasks: TaskItem[];
  task_completions: TaskCompletion[];
  surveys: SurveyItem[];
  survey_responses: SurveyResponse[];
  daily_rewards: Array<{ id: string; userId: string; rewardRs: number; claimedAt: string }>;
  referrals: Array<{ id: string; referrerId: string; referredUserId: string; rewardRs: number; status: string; createdAt: string }>;
  transactions: Transaction[];
  withdrawals: Withdrawal[];
  settings: AppSettings;
}

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'mraliasghar.json');

// Ensure data directory exists safely
try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (err) {
  console.warn('Could not initialize DATA_DIR:', err);
}

// In-memory cache synced with disk
let db: DatabaseSchema;

function getInitialSettings(): AppSettings {
  return {
    websiteName: 'MR Aliasghar',
    currencySymbol: 'Rs',
    minWithdrawal: 100,
    maxWithdrawal: 50000,
    withdrawalFeePercent: 0,
    referralRewardRs: 10,
    dailyRewardRs: 2,
    availableWithdrawalMethods: ['JazzCash', 'Easypaisa', 'Binance'] as PaymentMethod[],
    supportEmail: 'support@mraliasghar.com',
    supportPhone: '+92 300 1234567',
    termsUpdated: '2026-01-01',
  };
}

function getSeedTasks(): TaskItem[] {
  return [
    {
      id: 'task_yt_official',
      title: 'Visit & Subscribe Official YouTube Channel',
      platform: 'YouTube',
      description: 'Explore our latest official YouTube videos and guides on verified digital opportunities in Pakistan.',
      destinationUrl: 'https://youtube.com/@aliasgharpadda?si=OZyKzuTJ8J_yT4Iq',
      rewardRs: 6,
      dailyLimit: 200,
      totalLimit: 5000,
      completionsCount: 14,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'timed_visit',
      minDwellSeconds: 20,
      requiresProof: true,
      proofPrompt: 'Enter your YouTube handle or username for verified participation',
    },
    {
      id: 'task_tiktok_explore',
      title: 'Visit & Follow Official TikTok Account',
      platform: 'TikTok',
      description: 'Check out short informational videos regarding reward eligibility, Pakistan e-commerce, and tips.',
      destinationUrl: 'https://www.tiktok.com/@hafizgulaamabbasqadri?_r=1&_t=ZS-99vanqLYWAe',
      rewardRs: 3.6,
      dailyLimit: 300,
      totalLimit: 8000,
      completionsCount: 22,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'timed_visit',
      minDwellSeconds: 15,
      requiresProof: true,
      proofPrompt: 'Enter your TikTok username',
    },
    {
      id: 'task_facebook_page',
      title: 'Follow & Visit Official Facebook Page',
      platform: 'Facebook',
      description: 'Browse legitimate platform announcements, withdrawal schedules, and community guidelines.',
      destinationUrl: 'https://www.facebook.com/share/16CrChpyJjc/',
      rewardRs: 4.8,
      dailyLimit: 250,
      totalLimit: 6000,
      completionsCount: 9,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'timed_visit',
      minDwellSeconds: 15,
      requiresProof: false,
    },
    {
      id: 'task_insta_news',
      title: 'Follow & Check Official Instagram Account',
      platform: 'Instagram',
      description: 'Stay updated with visual guides and platform milestones on our Instagram feed.',
      destinationUrl: 'https://www.instagram.com/mrkingofnarowal?stkn=dXJzN2EwMzRid21l',
      rewardRs: 3.6,
      dailyLimit: 200,
      totalLimit: 5000,
      completionsCount: 18,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'timed_visit',
      minDwellSeconds: 15,
      requiresProof: true,
      proofPrompt: 'Enter your Instagram username or profile link',
    },
    {
      id: 'task_web_visit',
      title: 'Read Pakistan Digital Financial Inclusion Guide',
      platform: 'Website Visit',
      description: 'Read our verified blog post on safe digital wallet practices across JazzCash, Easypaisa, and Raast.',
      destinationUrl: 'https://en.wikipedia.org/wiki/Branchless_banking_in_Pakistan',
      rewardRs: 7.2,
      dailyLimit: 150,
      totalLimit: 3000,
      completionsCount: 31,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'timed_visit',
      minDwellSeconds: 25,
      requiresProof: false,
    },
    {
      id: 'task_ai_mrking_logo',
      title: "AI Design & Upload 'MR King' Logo",
      platform: 'AI Design',
      description: "Generate a custom AI logo for 'MR King' using any image AI tool and upload your artwork on the website. Earn guaranteed Rs 60.00 instantly!",
      destinationUrl: '/mrking-logo',
      rewardRs: 60,
      dailyLimit: 500,
      totalLimit: 10000,
      completionsCount: 48,
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      status: 'active',
      verificationMethod: 'image_upload',
      minDwellSeconds: 0,
      requiresProof: true,
      proofPrompt: "Upload your AI-generated MR King logo image and prompt used",
    },
  ];
}

function getSeedSurveys(): SurveyItem[] {
  return [
    {
      id: 'survey_ecommerce_pk',
      title: 'E-Commerce & Online Shopping Habits in Pakistan',
      description: 'Help e-commerce research teams understand Pakistani shopping preferences, delivery expectations, and payment options.',
      rewardRs: 25,
      durationMinutes: 4,
      maxParticipants: 1000,
      completedCount: 42,
      status: 'active',
      createdAt: '2026-01-10T10:00:00Z',
      questions: [
        {
          id: 'q1',
          question: 'How often do you make online purchases in Pakistan?',
          type: 'multiple_choice',
          options: ['Multiple times a week', 'Once a week', '2-3 times a month', 'Rarely / Never'],
          required: true,
        },
        {
          id: 'q2',
          question: 'Which payment method do you primarily trust for online shopping?',
          type: 'multiple_choice',
          options: ['Cash on Delivery (COD)', 'JazzCash Mobile Account', 'Easypaisa Mobile Account', 'Bank Debit/Credit Card'],
          required: true,
        },
        {
          id: 'q3',
          question: 'Do you prefer ordering from mobile apps rather than desktop websites?',
          type: 'yes_no',
          options: ['Yes', 'No'],
          required: true,
        },
        {
          id: 'q4',
          question: 'What is the biggest factor when deciding where to shop online?',
          type: 'multiple_choice',
          options: ['Price & Discounts', 'Fast Delivery Speed', 'Authentic Product Reviews', 'Easy Return Policy'],
          required: true,
        },
        {
          id: 'q5',
          question: 'What improvements would make you shop online more often in Pakistan?',
          type: 'short_answer',
          required: true,
        },
      ],
    },
    {
      id: 'survey_fintech_pk',
      title: 'Digital Wallets & Branchless Banking Survey',
      description: 'Share your insights on mobile wallets such as JazzCash, Easypaisa, and Raast instant payment system.',
      rewardRs: 30,
      durationMinutes: 5,
      maxParticipants: 800,
      completedCount: 29,
      status: 'active',
      createdAt: '2026-01-15T12:00:00Z',
      questions: [
        {
          id: 'fq1',
          question: 'Which mobile wallet account do you use most frequently?',
          type: 'multiple_choice',
          options: ['JazzCash', 'Easypaisa', 'SadaPay / NayaPay', 'Commercial Bank Mobile App'],
          required: true,
        },
        {
          id: 'fq2',
          question: 'Have you used Pakistan Raast ID for sending or receiving money without fees?',
          type: 'yes_no',
          options: ['Yes', 'No'],
          required: true,
        },
        {
          id: 'fq3',
          question: 'What is your primary use case for digital wallets?',
          type: 'multiple_choice',
          options: ['Utility Bill Payments', 'Mobile Top-ups (Loads)', 'Sending money to family/friends', 'Online retail checkout'],
          required: true,
        },
        {
          id: 'fq4',
          question: 'How satisfied are you with customer service and withdrawal agents in your area?',
          type: 'multiple_choice',
          options: ['Very Satisfied', 'Somewhat Satisfied', 'Neutral', 'Dissatisfied'],
          required: true,
        },
        {
          id: 'fq5',
          question: 'What feature would you like digital wallet providers to introduce next in Pakistan?',
          type: 'short_answer',
          required: true,
        },
      ],
    },
    {
      id: 'survey_mobile_tech',
      title: 'Smartphone & Internet Connectivity Research',
      description: 'Contribute to national tech metrics on 4G/5G mobile data coverage, devices, and online usage.',
      rewardRs: 20,
      durationMinutes: 3,
      maxParticipants: 500,
      completedCount: 15,
      status: 'active',
      createdAt: '2026-02-01T09:00:00Z',
      questions: [
        {
          id: 'tq1',
          question: 'Which mobile telecom network provides your primary data SIM?',
          type: 'multiple_choice',
          options: ['Jazz', 'Zong 4G', 'Telenor', 'Ufone 4G'],
          required: true,
        },
        {
          id: 'tq2',
          question: 'Do you currently have fiber broadband Wi-Fi at home?',
          type: 'yes_no',
          options: ['Yes', 'No'],
          required: true,
        },
        {
          id: 'tq3',
          question: 'Approximately how many hours per day do you spend on mobile internet for learning or earning?',
          type: 'multiple_choice',
          options: ['Less than 1 hour', '1 to 3 hours', '3 to 5 hours', 'More than 5 hours'],
          required: true,
        },
        {
          id: 'tq4',
          question: 'What is your primary mobile device operating system?',
          type: 'multiple_choice',
          options: ['Android', 'iOS (Apple iPhone)', 'Other'],
          required: true,
        },
      ],
    },
  ];
}

function loadDatabase(): DatabaseSchema {
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(raw);
    } catch (e) {
      console.error('Error reading database file, creating fresh backup:', e);
    }
  }

  // Generate seed admin
  const salt = bcrypt.genSaltSync(10);
  const adminPasswordHash = bcrypt.hashSync('Admin@123456', salt);
  const testUserPasswordHash = bcrypt.hashSync('User@123456', salt);

  const adminUser: User & { passwordHash: string } = {
    id: 'usr_admin001',
    name: 'MR Aliasghar Admin',
    email: 'admin@mraliasghar.com',
    phone: '+92 300 0000000',
    role: 'admin',
    status: 'active',
    referralCode: 'MRA-VIP001',
    referredBy: null,
    createdAt: new Date().toISOString(),
    lastLogin: new Date().toISOString(),
    passwordHash: adminPasswordHash,
  };

  const demoUser: User & { passwordHash: string } = {
    id: 'usr_demo001',
    name: 'Tariq Mehmood',
    email: 'tariq@example.com',
    phone: '+92 301 9876543',
    role: 'user',
    status: 'active',
    referralCode: 'MRA-TM77',
    referredBy: 'MRA-VIP001',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    lastLogin: new Date().toISOString(),
    passwordHash: testUserPasswordHash,
  };

  const initialWallets: Record<string, Wallet> = {
    [adminUser.id]: {
      userId: adminUser.id,
      availableBalance: 500,
      totalEarned: 500,
      totalWithdrawn: 0,
      pendingWithdrawal: 0,
      updatedAt: new Date().toISOString(),
    },
    [demoUser.id]: {
      userId: demoUser.id,
      availableBalance: 85,
      totalEarned: 85,
      totalWithdrawn: 0,
      pendingWithdrawal: 0,
      updatedAt: new Date().toISOString(),
    },
  };

  const initialTransactions: Transaction[] = [
    {
      id: 'TXN-908124',
      userId: demoUser.id,
      amount: 25,
      type: 'Survey Reward',
      status: 'completed',
      description: 'Completed E-Commerce & Online Shopping Habits in Pakistan',
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
    {
      id: 'TXN-908125',
      userId: demoUser.id,
      amount: 5,
      type: 'Task Reward',
      status: 'completed',
      description: 'Completed Visit Official MR Aliasghar YouTube Channel',
      createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    },
    {
      id: 'TXN-908126',
      userId: demoUser.id,
      amount: 2,
      type: 'Daily Reward',
      status: 'completed',
      description: 'Daily Check-in Reward credited',
      createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    },
  ];

  const seed: DatabaseSchema = {
    users: [adminUser, demoUser],
    wallets: initialWallets,
    tasks: getSeedTasks(),
    task_completions: [
      {
        id: 'comp_demo_01',
        taskId: 'task_yt_official',
        taskTitle: 'Visit Official MR Aliasghar YouTube Channel',
        userId: demoUser.id,
        rewardRs: 5,
        completedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
        verificationStatus: 'verified',
        proofText: '@tariq_yt',
      },
    ],
    surveys: getSeedSurveys(),
    survey_responses: [
      {
        id: 'resp_demo_01',
        surveyId: 'survey_ecommerce_pk',
        surveyTitle: 'E-Commerce & Online Shopping Habits in Pakistan',
        userId: demoUser.id,
        answers: {
          q1: 'Once a week',
          q2: 'Cash on Delivery (COD)',
          q3: 'Yes',
          q4: 'Price & Discounts',
          q5: 'Faster 24-hour delivery across Punjab and Sindh',
        },
        rewardRs: 25,
        submittedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      },
    ],
    daily_rewards: [
      {
        id: 'dr_demo_01',
        userId: demoUser.id,
        rewardRs: 2,
        claimedAt: new Date(Date.now() - 86400000 * 1.5).toISOString(),
      },
    ],
    referrals: [],
    transactions: initialTransactions,
    withdrawals: [],
    settings: getInitialSettings(),
  };

  saveDatabase(seed);
  return seed;
}

function saveDatabase(data: DatabaseSchema) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmpFile, DB_FILE);
    db = data;
  } catch (err) {
    console.error('Database write error, attempting direct sync:', err);
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
      db = data;
    } catch (e) {
      console.error('Direct database fallback write failed:', e);
    }
  }
}

// Initialize on module load
db = loadDatabase();

export const database = {
  get: () => db,

  save: () => {
    saveDatabase(db);
  },

  // USERS
  findUserByEmail: (email: string) => {
    return db.users.find((u) => u.email.toLowerCase() === email.toLowerCase().trim());
  },

  findUserById: (id: string) => {
    return db.users.find((u) => u.id === id);
  },

  findUserByReferralCode: (code: string) => {
    return db.users.find((u) => u.referralCode.toUpperCase() === code.toUpperCase().trim());
  },

  createUser: (userData: {
    name: string;
    email: string;
    passwordHash: string;
    phone?: string;
    referredBy?: string | null;
  }) => {
    const id = `usr_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const referralCode = `MRA-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    const newUser: User & { passwordHash: string } = {
      id,
      name: userData.name.trim(),
      email: userData.email.toLowerCase().trim(),
      phone: userData.phone?.trim() || '',
      role: 'user',
      status: 'active',
      referralCode,
      referredBy: userData.referredBy || null,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      passwordHash: userData.passwordHash,
    };

    db.users.push(newUser);

    // Initialize wallet
    db.wallets[id] = {
      userId: id,
      availableBalance: 0,
      totalEarned: 0,
      totalWithdrawn: 0,
      pendingWithdrawal: 0,
      updatedAt: new Date().toISOString(),
    };

    // If referred by a legitimate user, handle referral record
    if (userData.referredBy) {
      const referrer = db.users.find((u) => u.referralCode.toUpperCase() === userData.referredBy?.toUpperCase());
      if (referrer && referrer.id !== id) {
        const refReward = db.settings.referralRewardRs || 10;
        const refId = `ref_${Date.now()}`;
        db.referrals.push({
          id: refId,
          referrerId: referrer.id,
          referredUserId: id,
          rewardRs: refReward,
          status: 'credited',
          createdAt: new Date().toISOString(),
        });

        // Credit referrer wallet
        database.creditUserBalance(
          referrer.id,
          refReward,
          'Referral Reward',
          `Referral bonus for inviting verified user ${newUser.name}`
        );
      }
    }

    saveDatabase(db);
    return newUser;
  },

  updateUserLastLogin: (id: string) => {
    const user = db.users.find((u) => u.id === id);
    if (user) {
      user.lastLogin = new Date().toISOString();
      saveDatabase(db);
    }
  },

  updateUserProfile: (id: string, updates: { name?: string; phone?: string; passwordHash?: string }) => {
    const user = db.users.find((u) => u.id === id);
    if (!user) return null;
    if (updates.name) user.name = updates.name.trim();
    if (updates.phone !== undefined) user.phone = updates.phone.trim();
    if (updates.passwordHash) user.passwordHash = updates.passwordHash;
    saveDatabase(db);
    return user;
  },

  toggleUserStatus: (id: string) => {
    const user = db.users.find((u) => u.id === id);
    if (!user) return null;
    user.status = user.status === 'active' ? 'suspended' : 'active';
    saveDatabase(db);
    return user;
  },

  // WALLET & TRANSACTIONS
  getWallet: (userId: string): Wallet => {
    if (!db.wallets[userId]) {
      db.wallets[userId] = {
        userId,
        availableBalance: 0,
        totalEarned: 0,
        totalWithdrawn: 0,
        pendingWithdrawal: 0,
        updatedAt: new Date().toISOString(),
      };
      saveDatabase(db);
    }
    return db.wallets[userId];
  },

  creditUserBalance: (
    userId: string,
    amount: number,
    type: Transaction['type'],
    description: string
  ): { wallet: Wallet; transaction: Transaction } => {
    const wallet = database.getWallet(userId);
    const safeAmount = Math.max(0, Math.round(amount * 100) / 100);

    wallet.availableBalance = Math.round((wallet.availableBalance + safeAmount) * 100) / 100;
    wallet.totalEarned = Math.round((wallet.totalEarned + safeAmount) * 100) / 100;
    wallet.updatedAt = new Date().toISOString();

    const txnId = `TXN-${Date.now().toString().slice(-6)}${Math.floor(100 + Math.random() * 900)}`;
    const transaction: Transaction = {
      id: txnId,
      userId,
      amount: safeAmount,
      type,
      status: 'completed',
      description,
      createdAt: new Date().toISOString(),
    };

    db.transactions.unshift(transaction);
    saveDatabase(db);
    return { wallet, transaction };
  },

  requestWithdrawal: (
    userId: string,
    amount: number,
    paymentMethod: PaymentMethod,
    accountDetails: Withdrawal['accountDetails']
  ): { withdrawal: Withdrawal; wallet: Wallet } => {
    const wallet = database.getWallet(userId);
    const safeAmount = Math.round(amount * 100) / 100;

    if (safeAmount < db.settings.minWithdrawal) {
      throw new Error(`Minimum withdrawal amount is Rs ${db.settings.minWithdrawal}.`);
    }

    if (safeAmount > db.settings.maxWithdrawal) {
      throw new Error(`Maximum withdrawal amount is Rs ${db.settings.maxWithdrawal}.`);
    }

    if (wallet.availableBalance < safeAmount) {
      throw new Error(`Insufficient available balance. You have Rs ${wallet.availableBalance.toFixed(2)}.`);
    }

    const feePercent = db.settings.withdrawalFeePercent || 0;
    const fee = Math.round(((safeAmount * feePercent) / 100) * 100) / 100;
    const netAmount = Math.round((safeAmount - fee) * 100) / 100;

    // Server-side safe deduction
    wallet.availableBalance = Math.round((wallet.availableBalance - safeAmount) * 100) / 100;
    wallet.pendingWithdrawal = Math.round((wallet.pendingWithdrawal + safeAmount) * 100) / 100;
    wallet.updatedAt = new Date().toISOString();

    const user = db.users.find((u) => u.id === userId);
    const withdrawalId = `WD-${Date.now().toString().slice(-6)}${Math.floor(100 + Math.random() * 900)}`;

    const withdrawal: Withdrawal = {
      id: withdrawalId,
      userId,
      userName: user?.name || 'User',
      userEmail: user?.email || '',
      amount: safeAmount,
      fee,
      netAmount,
      paymentMethod,
      accountDetails,
      status: 'Pending',
      adminNote: 'Withdrawal submitted — waiting for admin processing.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.withdrawals.unshift(withdrawal);

    // Record pending transaction
    const txnId = `TXN-${Date.now().toString().slice(-6)}${Math.floor(100 + Math.random() * 900)}`;
    const transaction: Transaction = {
      id: txnId,
      userId,
      amount: -safeAmount,
      type: 'Withdrawal',
      status: 'pending',
      description: `Withdrawal request of Rs ${safeAmount} via ${paymentMethod} (${withdrawalId})`,
      createdAt: new Date().toISOString(),
    };
    db.transactions.unshift(transaction);

    saveDatabase(db);
    return { withdrawal, wallet };
  },

  updateWithdrawalStatus: (
    withdrawalId: string,
    newStatus: WithdrawalStatus,
    adminNote?: string
  ): Withdrawal => {
    const wd = db.withdrawals.find((w) => w.id === withdrawalId);
    if (!wd) throw new Error('Withdrawal record not found.');

    const wallet = database.getWallet(wd.userId);
    const previousStatus = wd.status;

    wd.status = newStatus;
    wd.updatedAt = new Date().toISOString();
    if (adminNote) wd.adminNote = adminNote;

    // Handle financial accounting transitions
    if (
      (newStatus === 'Rejected' || newStatus === 'Cancelled') &&
      previousStatus !== 'Rejected' &&
      previousStatus !== 'Cancelled'
    ) {
      // Revert funds back to user
      wallet.pendingWithdrawal = Math.max(0, Math.round((wallet.pendingWithdrawal - wd.amount) * 100) / 100);
      wallet.availableBalance = Math.round((wallet.availableBalance + wd.amount) * 100) / 100;
      wallet.updatedAt = new Date().toISOString();

      // Log reversal transaction
      const txnId = `TXN-${Date.now().toString().slice(-6)}${Math.floor(100 + Math.random() * 900)}`;
      db.transactions.unshift({
        id: txnId,
        userId: wd.userId,
        amount: wd.amount,
        type: 'Withdrawal Reversal',
        status: 'completed',
        description: `Refund for ${newStatus} withdrawal ${wd.id}. ${adminNote ? `Reason: ${adminNote}` : ''}`,
        createdAt: new Date().toISOString(),
      });
    } else if (newStatus === 'Paid' && previousStatus !== 'Paid') {
      // Finalize paid withdrawal
      wallet.pendingWithdrawal = Math.max(0, Math.round((wallet.pendingWithdrawal - wd.amount) * 100) / 100);
      wallet.totalWithdrawn = Math.round((wallet.totalWithdrawn + wd.amount) * 100) / 100;
      wallet.updatedAt = new Date().toISOString();

      // Update matching transaction status to completed
      const matchingTxn = db.transactions.find(
        (t) => t.userId === wd.userId && t.type === 'Withdrawal' && t.description.includes(wd.id)
      );
      if (matchingTxn) {
        matchingTxn.status = 'completed';
      }
    }

    saveDatabase(db);
    return wd;
  },

  // DAILY REWARD
  getDailyRewardStatus: (userId: string) => {
    const claims = db.daily_rewards.filter((r) => r.userId === userId);
    claims.sort((a, b) => new Date(b.claimedAt).getTime() - new Date(a.claimedAt).getTime());

    const lastClaim = claims[0];
    const rewardRs = db.settings.dailyRewardRs || 2;
    const cooldownMs = 24 * 60 * 60 * 1000;

    if (!lastClaim) {
      return {
        rewardRs,
        canClaim: true,
        lastClaimTime: null,
        nextClaimTime: null,
        secondsRemaining: 0,
      };
    }

    const lastTime = new Date(lastClaim.claimedAt).getTime();
    const now = Date.now();
    const elapsed = now - lastTime;
    const remaining = Math.max(0, cooldownMs - elapsed);

    return {
      rewardRs,
      canClaim: remaining === 0,
      lastClaimTime: lastClaim.claimedAt,
      nextClaimTime: new Date(lastTime + cooldownMs).toISOString(),
      secondsRemaining: Math.ceil(remaining / 1000),
    };
  },

  claimDailyReward: (userId: string) => {
    const status = database.getDailyRewardStatus(userId);
    if (!status.canClaim) {
      throw new Error(`Daily reward not available yet. Please wait ${Math.ceil(status.secondsRemaining / 60)} minutes.`);
    }

    const rewardRs = db.settings.dailyRewardRs || 2;
    const recordId = `dr_${Date.now()}`;
    db.daily_rewards.push({
      id: recordId,
      userId,
      rewardRs,
      claimedAt: new Date().toISOString(),
    });

    database.creditUserBalance(
      userId,
      rewardRs,
      'Daily Reward',
      `Daily check-in reward claimed (+Rs ${rewardRs.toFixed(2)})`
    );

    saveDatabase(db);
    return { rewardRs, nextClaimTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() };
  },

  // TASKS
  getTasksForUser: (userId: string): TaskItem[] => {
    const completedTaskIds = new Set(
      db.task_completions.filter((c) => c.userId === userId && c.verificationStatus === 'verified').map((c) => c.taskId)
    );

    return db.tasks.map((task) => ({
      ...task,
      isCompletedByUser: completedTaskIds.has(task.id),
    }));
  },

  completeTask: (
    userId: string,
    taskId: string,
    proofText?: string,
    proofImageUrl?: string
  ): { task: TaskItem; completion: TaskCompletion; wallet: Wallet } => {
    const task = db.tasks.find((t) => t.id === taskId);
    if (!task) throw new Error('Task not found.');

    if (task.status !== 'active') {
      throw new Error('This task is currently inactive.');
    }

    // Check if user already completed this task
    const existing = db.task_completions.find((c) => c.userId === userId && c.taskId === taskId);
    if (existing && existing.verificationStatus === 'verified') {
      throw new Error('You have already completed and claimed rewards for this task.');
    }

    // Check completion limits
    if (task.totalLimit && task.completionsCount >= task.totalLimit) {
      throw new Error('This task has reached its total participant limit.');
    }

    if (task.requiresProof && (!proofText || proofText.trim().length < 2) && !proofImageUrl) {
      throw new Error('Verification proof or logo upload is required for this promotional task.');
    }

    // Increment task completions count
    task.completionsCount += 1;

    const completionId = `comp_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
    const completion: TaskCompletion = {
      id: completionId,
      taskId,
      taskTitle: task.title,
      userId,
      rewardRs: task.rewardRs,
      completedAt: new Date().toISOString(),
      verificationStatus: 'verified',
      proofText: proofText?.trim(),
      proofImageUrl: proofImageUrl?.trim(),
    };

    db.task_completions.push(completion);

    // Credit reward to wallet
    const { wallet } = database.creditUserBalance(
      userId,
      task.rewardRs,
      'Task Reward',
      `Completed: ${task.title}`
    );

    saveDatabase(db);
    return { task, completion, wallet };
  },

  // SURVEYS
  getSurveysForUser: (userId: string): SurveyItem[] => {
    const completedSurveyIds = new Set(
      db.survey_responses.filter((r) => r.userId === userId).map((r) => r.surveyId)
    );

    return db.surveys.map((s) => ({
      ...s,
      isCompletedByUser: completedSurveyIds.has(s.id),
    }));
  },

  submitSurvey: (
    userId: string,
    surveyId: string,
    answers: Record<string, string | string[]>
  ): { survey: SurveyItem; rewardRs: number; wallet: Wallet } => {
    const survey = db.surveys.find((s) => s.id === surveyId);
    if (!survey) throw new Error('Survey not found.');

    if (survey.status !== 'active') {
      throw new Error('This survey is currently closed.');
    }

    const alreadyDone = db.survey_responses.find((r) => r.userId === userId && r.surveyId === surveyId);
    if (alreadyDone) {
      throw new Error('You have already submitted responses for this survey.');
    }

    if (survey.maxParticipants && survey.completedCount >= survey.maxParticipants) {
      throw new Error('This survey has reached its maximum participant response quota.');
    }

    // Validate required questions
    for (const q of survey.questions) {
      if (q.required) {
        const ans = answers[q.id];
        if (!ans || (typeof ans === 'string' && ans.trim().length === 0)) {
          throw new Error(`Please answer the required question: "${q.question}"`);
        }
      }
    }

    survey.completedCount += 1;

    const responseId = `resp_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`;
    db.survey_responses.push({
      id: responseId,
      surveyId,
      surveyTitle: survey.title,
      userId,
      answers,
      rewardRs: survey.rewardRs,
      submittedAt: new Date().toISOString(),
    });

    // Credit user
    const { wallet } = database.creditUserBalance(
      userId,
      survey.rewardRs,
      'Survey Reward',
      `Survey completed: ${survey.title}`
    );

    saveDatabase(db);
    return { survey, rewardRs: survey.rewardRs, wallet };
  },

  // REFERRALS
  getReferralStats: (userId: string) => {
    const user = db.users.find((u) => u.id === userId);
    if (!user) throw new Error('User not found');

    const refs = db.referrals.filter((r) => r.referrerId === userId);
    const totalEarnings = refs.reduce((sum, r) => sum + r.rewardRs, 0);

    const detailedRefs = refs.map((r) => {
      const refUser = db.users.find((u) => u.id === r.referredUserId);
      return {
        id: r.id,
        referredUserName: refUser ? refUser.name : 'Verified Member',
        joinedAt: r.createdAt,
        rewardRs: r.rewardRs,
        status: r.status,
      };
    });

    return {
      referralCode: user.referralCode,
      referralLink: `/register?ref=${user.referralCode}`,
      totalReferrals: refs.length,
      totalReferralEarnings: totalEarnings,
      rewardPerReferral: db.settings.referralRewardRs || 10,
      referrals: detailedRefs,
    };
  },

  // ADMIN
  getAdminMetrics: () => {
    const totalUsers = db.users.length;
    const activeUsers = db.users.filter((u) => u.status === 'active').length;
    const pendingWithdrawals = db.withdrawals.filter((w) => w.status === 'Pending' || w.status === 'Processing');
    const paidWithdrawals = db.withdrawals.filter((w) => w.status === 'Paid');

    const totalRewards = Object.values(db.wallets).reduce((sum, w) => sum + (w.totalEarned || 0), 0);

    return {
      totalUsers,
      activeUsers,
      totalRewardsDistributedRs: Math.round(totalRewards * 100) / 100,
      pendingWithdrawalsCount: pendingWithdrawals.length,
      pendingWithdrawalsAmountRs: pendingWithdrawals.reduce((sum, w) => sum + w.amount, 0),
      paidWithdrawalsCount: paidWithdrawals.length,
      paidWithdrawalsAmountRs: paidWithdrawals.reduce((sum, w) => sum + w.amount, 0),
      activeSurveysCount: db.surveys.filter((s) => s.status === 'active').length,
      activeTasksCount: db.tasks.filter((t) => t.status === 'active').length,
      totalTransactionsCount: db.transactions.length,
    };
  },
};
