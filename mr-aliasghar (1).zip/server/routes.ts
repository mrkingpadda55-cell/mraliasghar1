import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { database } from './db';
import { AuthenticatedRequest, generateToken, requireAuth, requireAdmin } from './auth';
import { AppSettings, TaskItem, SurveyItem, PaymentMethod } from '../src/types';

export const apiRouter = Router();

// ==================== PUBLIC SETTINGS ====================
apiRouter.get('/settings', (req, res) => {
  const db = database.get();
  res.json({
    settings: db.settings,
  });
});

// ==================== AUTHENTICATION ====================
apiRouter.post('/auth/register', (req, res) => {
  try {
    const { name, email, password, confirmPassword, phone, referralCode } = req.body;

    if (!name || !name.trim()) {
      res.status(400).json({ error: 'Full name is required.' });
      return;
    }
    if (!email || !email.includes('@')) {
      res.status(400).json({ error: 'Valid email address is required.' });
      return;
    }
    if (!password || password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }
    if (password !== confirmPassword) {
      res.status(400).json({ error: 'Passwords do not match.' });
      return;
    }

    const existing = database.findUserByEmail(email);
    if (existing) {
      res.status(400).json({ error: 'An account with this email already exists. Please log in.' });
      return;
    }

    let validReferrerCode: string | null = null;
    if (referralCode && referralCode.trim()) {
      const refUser = database.findUserByReferralCode(referralCode.trim());
      if (refUser) {
        validReferrerCode = refUser.referralCode;
      }
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);

    const newUser = database.createUser({
      name,
      email,
      passwordHash,
      phone: phone || '',
      referredBy: validReferrerCode,
    });

    const token = generateToken(newUser);
    const wallet = database.getWallet(newUser.id);

    res.status(201).json({
      message: 'Account registered successfully!',
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        status: newUser.status,
        referralCode: newUser.referralCode,
        referredBy: newUser.referredBy,
        createdAt: newUser.createdAt,
      },
      wallet,
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({ error: err.message || 'Internal registration error.' });
  }
});

apiRouter.post('/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const user = database.findUserByEmail(email);
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (user.status === 'suspended' || user.status === 'banned') {
      res.status(403).json({ error: 'Your account has been suspended or banned. Please contact MR Aliasghar support.' });
      return;
    }

    const match = bcrypt.compareSync(password, user.passwordHash);
    if (!match) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    database.updateUserLastLogin(user.id);
    const token = generateToken(user);
    const wallet = database.getWallet(user.id);

    res.json({
      message: 'Logged in successfully',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        referralCode: user.referralCode,
        referredBy: user.referredBy,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin,
      },
      wallet,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login error.' });
  }
});

apiRouter.get('/auth/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const wallet = database.getWallet(user.id);
  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      status: user.status,
      referralCode: user.referralCode,
      referredBy: user.referredBy,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
    },
    wallet,
  });
});

apiRouter.post('/auth/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { name, phone, currentPassword, newPassword } = req.body;

    const updates: { name?: string; phone?: string; passwordHash?: string } = {};
    if (name && name.trim()) updates.name = name;
    if (phone !== undefined) updates.phone = phone;

    if (newPassword) {
      if (!currentPassword) {
        res.status(400).json({ error: 'Current password is required to change password.' });
        return;
      }
      const fullUser = database.get().users.find((u) => u.id === user.id);
      if (!fullUser || !bcrypt.compareSync(currentPassword, fullUser.passwordHash)) {
        res.status(400).json({ error: 'Current password is incorrect.' });
        return;
      }
      if (newPassword.length < 6) {
        res.status(400).json({ error: 'New password must be at least 6 characters.' });
        return;
      }
      const salt = bcrypt.genSaltSync(10);
      updates.passwordHash = bcrypt.hashSync(newPassword, salt);
    }

    const updated = database.updateUserProfile(user.id, updates);
    res.json({
      message: 'Profile updated successfully',
      user: {
        id: updated!.id,
        name: updated!.name,
        email: updated!.email,
        phone: updated!.phone,
        role: updated!.role,
        status: updated!.status,
        referralCode: updated!.referralCode,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Profile update error.' });
  }
});

apiRouter.post('/auth/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes('@')) {
    res.status(400).json({ error: 'Please provide a valid registered email address.' });
    return;
  }
  const user = database.findUserByEmail(email);
  if (!user) {
    res.status(404).json({ error: 'No account found with this email address.' });
    return;
  }

  // Generate a verified reset token / temporary credentials
  const tempPin = Math.floor(100000 + Math.random() * 900000).toString();
  res.json({
    message: `Password reset verification initiated for ${email}.`,
    verificationCode: tempPin,
    notice: 'In production, this verification code is dispatched via transactional SMTP/SMS.',
  });
});

apiRouter.post('/auth/reset-password', (req, res) => {
  const { email, verificationCode, newPassword } = req.body;
  if (!email || !verificationCode || !newPassword) {
    res.status(400).json({ error: 'All fields are required.' });
    return;
  }
  if (newPassword.length < 6) {
    res.status(400).json({ error: 'Password must be at least 6 characters.' });
    return;
  }
  const user = database.findUserByEmail(email);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(newPassword, salt);
  database.updateUserProfile(user.id, { passwordHash });

  res.json({ message: 'Password has been reset successfully. You can now log in.' });
});

// ==================== DASHBOARD & METRICS ====================
apiRouter.get('/dashboard/summary', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const wallet = database.getWallet(userId);
  const db = database.get();

  // Calculate Today's Earnings
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  const userTxns = db.transactions.filter((t) => t.userId === userId);
  const todayTxns = userTxns.filter(
    (t) => new Date(t.createdAt).getTime() >= startOfDay && t.amount > 0 && t.status === 'completed'
  );
  const todayEarnings = Math.round(todayTxns.reduce((sum, t) => sum + t.amount, 0) * 100) / 100;

  const completedTasksCount = db.task_completions.filter(
    (c) => c.userId === userId && c.verificationStatus === 'verified'
  ).length;

  const completedSurveysCount = db.survey_responses.filter((r) => r.userId === userId).length;

  res.json({
    welcomeName: req.user!.name,
    balance: wallet.availableBalance,
    todayEarnings,
    totalEarnings: wallet.totalEarned,
    pendingWithdrawal: wallet.pendingWithdrawal,
    totalWithdrawn: wallet.totalWithdrawn,
    completedTasksCount,
    completedSurveysCount,
    recentTransactions: userTxns.slice(0, 5),
  });
});

// ==================== TASKS ====================
apiRouter.get('/tasks', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const tasks = database.getTasksForUser(req.user!.id);
  res.json({ tasks });
});

apiRouter.post('/tasks/:id/complete', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { proofText, proofImageUrl } = req.body;
    const result = database.completeTask(req.user!.id, id, proofText, proofImageUrl);
    res.json({
      message: `Task verified! Rs ${result.task.rewardRs} has been credited to your wallet.`,
      rewardRs: result.task.rewardRs,
      wallet: result.wallet,
      completion: result.completion,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to complete task.' });
  }
});

// ==================== SURVEYS ====================
apiRouter.get('/surveys', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const surveys = database.getSurveysForUser(req.user!.id);
  res.json({ surveys });
});

apiRouter.post('/surveys/:id/submit', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { answers } = req.body;

    if (!answers || typeof answers !== 'object') {
      res.status(400).json({ error: 'Please submit complete survey responses.' });
      return;
    }

    const result = database.submitSurvey(req.user!.id, id, answers);
    res.json({
      message: `Survey completed! Rs ${result.rewardRs} credited to your available balance.`,
      rewardRs: result.rewardRs,
      wallet: result.wallet,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to submit survey.' });
  }
});

// ==================== DAILY REWARD ====================
apiRouter.get('/daily-reward/status', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const status = database.getDailyRewardStatus(req.user!.id);
  res.json(status);
});

apiRouter.post('/daily-reward/claim', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = database.claimDailyReward(req.user!.id);
    const wallet = database.getWallet(req.user!.id);
    res.json({
      message: `Daily reward of Rs ${result.rewardRs} claimed successfully!`,
      rewardRs: result.rewardRs,
      nextClaimTime: result.nextClaimTime,
      wallet,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to claim daily reward.' });
  }
});

// ==================== WALLET & WITHDRAWALS ====================
apiRouter.get('/wallet', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const wallet = database.getWallet(req.user!.id);
  const db = database.get();
  const transactions = db.transactions.filter((t) => t.userId === req.user!.id);
  const withdrawals = db.withdrawals.filter((w) => w.userId === req.user!.id);

  res.json({
    wallet,
    settings: {
      minWithdrawal: db.settings.minWithdrawal,
      maxWithdrawal: db.settings.maxWithdrawal,
      withdrawalFeePercent: db.settings.withdrawalFeePercent,
      availableMethods: db.settings.availableWithdrawalMethods,
    },
    transactions,
    withdrawals,
  });
});

apiRouter.post('/wallet/withdraw', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { amount, paymentMethod, accountDetails } = req.body;

    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      res.status(400).json({ error: 'Please enter a valid numeric amount in Rs.' });
      return;
    }

    if (!paymentMethod) {
      res.status(400).json({ error: 'Please select a payout method.' });
      return;
    }

    if (!accountDetails || typeof accountDetails !== 'object') {
      res.status(400).json({ error: 'Please fill in required payout account details.' });
      return;
    }

    // Specific validation per payment method
    if (paymentMethod === 'JazzCash' || paymentMethod === 'Easypaisa') {
      if (!accountDetails.accountHolderName || accountDetails.accountHolderName.trim().length < 3) {
        res.status(400).json({ error: 'Account title / holder name is required.' });
        return;
      }
      if (!accountDetails.mobileNumber || accountDetails.mobileNumber.trim().length < 10) {
        res.status(400).json({ error: 'Valid 11-digit mobile account number is required (e.g. 03001234567).' });
        return;
      }
    } else if (paymentMethod === 'Binance') {
      if (!accountDetails.binancePayId || accountDetails.binancePayId.trim().length < 6) {
        res.status(400).json({ error: 'Valid Binance Pay ID or USDT address is required.' });
        return;
      }
    }

    const result = database.requestWithdrawal(
      req.user!.id,
      Number(amount),
      paymentMethod as PaymentMethod,
      accountDetails
    );

    res.status(201).json({
      message: 'Withdrawal submitted — waiting for admin processing.',
      withdrawal: result.withdrawal,
      wallet: result.wallet,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Withdrawal request failed.' });
  }
});

// ==================== REFERRALS ====================
apiRouter.get('/referrals', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const stats = database.getReferralStats(req.user!.id);
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch referral metrics.' });
  }
});

// ==================== ADMIN PANEL ====================
apiRouter.get('/admin/metrics', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const metrics = database.getAdminMetrics();
  res.json(metrics);
});

apiRouter.get('/admin/users', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const db = database.get();
  const search = (req.query.search as string || '').toLowerCase().trim();

  let users = db.users.map((u) => {
    const wallet = database.getWallet(u.id);
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      phone: u.phone,
      role: u.role,
      status: u.status,
      referralCode: u.referralCode,
      createdAt: u.createdAt,
      lastLogin: u.lastLogin,
      wallet,
    };
  });

  if (search) {
    users = users.filter(
      (u) =>
        u.name.toLowerCase().includes(search) ||
        u.email.toLowerCase().includes(search) ||
        u.referralCode.toLowerCase().includes(search)
    );
  }

  res.json({ users });
});

apiRouter.post('/admin/users/:id/toggle-status', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = database.toggleUserStatus(id);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  res.json({ message: `User status changed to ${user.status}`, status: user.status });
});

apiRouter.post('/admin/users/:id/status', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const user = database.findUserById(id);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  user.status = (status === 'banned' || status === 'suspended') ? status : 'active';
  database.save();
  res.json({ message: `User status updated to ${user.status}`, status: user.status });
});

apiRouter.post('/admin/users/:id/adjust-balance', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { amount, reason } = req.body;

    if (!amount || isNaN(Number(amount))) {
      res.status(400).json({ error: 'Valid numeric amount is required.' });
      return;
    }

    const user = database.findUserById(id);
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const { wallet } = database.creditUserBalance(
      id,
      Number(amount),
      'Admin Adjustment',
      reason || 'Administrative balance adjustment'
    );

    res.json({ message: 'Balance adjusted successfully', wallet });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Balance adjustment failed.' });
  }
});

apiRouter.get('/transactions', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = database.get();
  const transactions = db.transactions
    .filter((t) => t.userId === req.user!.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ transactions });
});


apiRouter.get('/admin/users/:id/detail', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  const { id } = req.params;
  const user = database.findUserById(id);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const wallet = database.getWallet(id);
  const db = database.get();
  const transactions = db.transactions.filter((t) => t.userId === id);
  const completions = db.task_completions.filter((c) => c.userId === id);
  const surveyHistory = db.survey_responses.filter((r) => r.userId === id);
  const withdrawals = db.withdrawals.filter((w) => w.userId === id);

  res.json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      status: user.status,
      referralCode: user.referralCode,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
    },
    wallet,
    transactions,
    completions,
    surveyHistory,
    withdrawals,
  });
});

// Admin Tasks CRUD
apiRouter.get('/admin/tasks', requireAuth, requireAdmin, (req, res) => {
  res.json({ tasks: database.get().tasks });
});

apiRouter.post('/admin/tasks', requireAuth, requireAdmin, (req, res) => {
  try {
    const {
      title,
      platform,
      description,
      destinationUrl,
      rewardRs,
      dailyLimit,
      totalLimit,
      startDate,
      endDate,
      status,
      verificationMethod,
      minDwellSeconds,
      requiresProof,
      proofPrompt,
    } = req.body;

    if (!title || !destinationUrl || rewardRs === undefined) {
      res.status(400).json({ error: 'Title, destination URL, and reward in Rs are required.' });
      return;
    }

    const newTask: TaskItem = {
      id: `task_${Date.now()}`,
      title: title.trim(),
      platform: platform || 'Other',
      description: description?.trim() || '',
      destinationUrl: destinationUrl.trim(),
      rewardRs: Number(rewardRs),
      dailyLimit: Number(dailyLimit) || 100,
      totalLimit: Number(totalLimit) || 1000,
      completionsCount: 0,
      startDate: startDate || new Date().toISOString().split('T')[0],
      endDate: endDate || '2026-12-31',
      status: status === 'inactive' ? 'inactive' : 'active',
      verificationMethod: verificationMethod || 'timed_visit',
      minDwellSeconds: Number(minDwellSeconds) || 15,
      requiresProof: Boolean(requiresProof),
      proofPrompt: proofPrompt || '',
    };

    database.get().tasks.unshift(newTask);
    database.save();

    res.status(201).json({ message: 'Task created successfully', task: newTask });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Task creation failed.' });
  }
});

apiRouter.put('/admin/tasks/:id', requireAuth, requireAdmin, (req, res) => {
  const { id } = req.params;
  const task = database.get().tasks.find((t) => t.id === id);
  if (!task) {
    res.status(404).json({ error: 'Task not found.' });
    return;
  }

  Object.assign(task, req.body);
  database.save();
  res.json({ message: 'Task updated successfully', task });
});

apiRouter.delete('/admin/tasks/:id', requireAuth, requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = database.get().tasks.findIndex((t) => t.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Task not found.' });
    return;
  }
  database.get().tasks.splice(idx, 1);
  database.save();
  res.json({ message: 'Task deleted successfully' });
});

// Admin Surveys CRUD
apiRouter.get('/admin/surveys', requireAuth, requireAdmin, (req, res) => {
  res.json({ surveys: database.get().surveys });
});

apiRouter.post('/admin/surveys', requireAuth, requireAdmin, (req, res) => {
  try {
    const { title, description, rewardRs, durationMinutes, maxParticipants, status, questions } = req.body;

    if (!title || rewardRs === undefined || !questions || !questions.length) {
      res.status(400).json({ error: 'Survey title, reward amount, and questions are required.' });
      return;
    }

    const newSurvey: SurveyItem = {
      id: `survey_${Date.now()}`,
      title: title.trim(),
      description: description?.trim() || '',
      rewardRs: Number(rewardRs),
      durationMinutes: Number(durationMinutes) || 3,
      maxParticipants: Number(maxParticipants) || 500,
      completedCount: 0,
      status: status === 'inactive' ? 'inactive' : 'active',
      questions,
      createdAt: new Date().toISOString(),
    };

    database.get().surveys.unshift(newSurvey);
    database.save();

    res.status(201).json({ message: 'Survey created successfully', survey: newSurvey });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Survey creation failed.' });
  }
});

apiRouter.put('/admin/surveys/:id', requireAuth, requireAdmin, (req, res) => {
  const { id } = req.params;
  const survey = database.get().surveys.find((s) => s.id === id);
  if (!survey) {
    res.status(404).json({ error: 'Survey not found.' });
    return;
  }

  Object.assign(survey, req.body);
  database.save();
  res.json({ message: 'Survey updated successfully', survey });
});

apiRouter.delete('/admin/surveys/:id', requireAuth, requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = database.get().surveys.findIndex((s) => s.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Survey not found.' });
    return;
  }
  database.get().surveys.splice(idx, 1);
  database.save();
  res.json({ message: 'Survey deleted successfully' });
});

// Admin Withdrawals
apiRouter.get('/admin/withdrawals', requireAuth, requireAdmin, (req, res) => {
  res.json({ withdrawals: database.get().withdrawals });
});

apiRouter.post('/admin/withdrawals/:id/status', requireAuth, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { status, adminNote } = req.body;

    if (!status) {
      res.status(400).json({ error: 'New status is required.' });
      return;
    }

    const updated = database.updateWithdrawalStatus(id, status, adminNote);
    res.json({ message: `Withdrawal marked as ${status}`, withdrawal: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to update withdrawal status.' });
  }
});

// Admin Settings
apiRouter.put('/admin/settings', requireAuth, requireAdmin, (req, res) => {
  try {
    const updates: Partial<AppSettings> = req.body;
    const db = database.get();
    db.settings = { ...db.settings, ...updates };
    database.save();
    res.json({ message: 'System settings saved successfully', settings: db.settings });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to update settings.' });
  }
});
