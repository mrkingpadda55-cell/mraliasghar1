import {
  User,
  Wallet,
  TaskItem,
  SurveyItem,
  Transaction,
  Withdrawal,
  DailyRewardStatus,
  ReferralStats,
  AppSettings,
  AdminMetrics,
  PaymentMethod,
} from '../types';

const TOKEN_KEY = 'mra_auth_token';

export const apiClient = {
  getToken: (): string | null => {
    return localStorage.getItem(TOKEN_KEY);
  },

  setToken: (token: string): void => {
    localStorage.setItem(TOKEN_KEY, token);
  },

  removeToken: (): void => {
    localStorage.removeItem(TOKEN_KEY);
  },

  async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = apiClient.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {}),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const baseUrl = import.meta.env.VITE_API_URL
      ? (import.meta.env.VITE_API_URL as string).replace(/\/+$/, '')
      : '';
    const url = `${baseUrl}/api${endpoint}`;

    let response: Response;
    try {
      response = await fetch(url, {
        ...options,
        headers,
      });
    } catch (networkErr: any) {
      console.error(`Network error connecting to ${url}:`, networkErr);
      throw new Error('Unable to connect to MR Aliasghar server. Please verify your internet connection or server availability.');
    }

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      if (response.status === 401 && token) {
        // If session expired or token is invalid, clear token
        apiClient.removeToken();
      }
      throw new Error(data.error || `Request failed with status ${response.status}`);
    }

    return data as T;
  },

  // Auth
  register: (body: any) => apiClient.request<{ message: string; token: string; user: User; wallet: Wallet }>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  login: (body: any) => apiClient.request<{ message: string; token: string; user: User; wallet: Wallet }>('/auth/login', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  getMe: () => apiClient.request<{ user: User; wallet: Wallet }>('/auth/me'),

  updateProfile: (body: any) => apiClient.request<{ message: string; user: User }>('/auth/profile', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  forgotPassword: (email: string) => apiClient.request<{ message: string; verificationCode?: string }>('/auth/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ email }),
  }),

  resetPassword: (body: any) => apiClient.request<{ message: string }>('/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  // Settings
  getSettings: () => apiClient.request<{ settings: AppSettings }>('/settings'),

  // Dashboard
  getDashboardSummary: () => apiClient.request<{
    welcomeName: string;
    balance: number;
    todayEarnings: number;
    totalEarnings: number;
    pendingWithdrawal: number;
    totalWithdrawn: number;
    completedTasksCount: number;
    completedSurveysCount: number;
    recentTransactions: Transaction[];
  }>('/dashboard/summary'),

  // Tasks
  getTasks: () => apiClient.request<{ tasks: TaskItem[] }>('/tasks'),

  completeTask: (taskId: string, proofText?: string, proofImageUrl?: string) =>
    apiClient.request<{ message: string; rewardRs: number; wallet: Wallet; completion: any }>(`/tasks/${taskId}/complete`, {
      method: 'POST',
      body: JSON.stringify({ proofText, proofImageUrl }),
    }),

  // Surveys
  getSurveys: () => apiClient.request<{ surveys: SurveyItem[] }>('/surveys'),

  submitSurvey: (surveyId: string, answers: Record<string, string | string[]>) =>
    apiClient.request<{ message: string; rewardRs: number; wallet: Wallet }>(`/surveys/${surveyId}/submit`, {
      method: 'POST',
      body: JSON.stringify({ answers }),
    }),

  // Daily Reward
  getDailyRewardStatus: () => apiClient.request<DailyRewardStatus>('/daily-reward/status'),

  claimDailyReward: () => apiClient.request<{ message: string; rewardRs: number; nextClaimTime: string; wallet: Wallet }>('/daily-reward/claim', {
    method: 'POST',
  }),

  // Wallet
  getWallet: () => apiClient.request<{
    wallet: Wallet;
    settings: {
      minWithdrawal: number;
      maxWithdrawal: number;
      withdrawalFeePercent: number;
      availableMethods: PaymentMethod[];
    };
    transactions: Transaction[];
    withdrawals: Withdrawal[];
  }>('/wallet'),

  requestWithdrawal: (body: { amount: number; paymentMethod: PaymentMethod; accountDetails: any }) =>
    apiClient.request<{ message: string; withdrawal: Withdrawal; wallet: Wallet }>('/wallet/withdraw', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // Referrals
  getReferrals: () => apiClient.request<ReferralStats>('/referrals'),

  // Admin
  getAdminMetrics: () => apiClient.request<AdminMetrics>('/admin/metrics'),

  getAdminUsers: (search?: string) =>
    apiClient.request<{ users: (User & { wallet: Wallet })[] }>(`/admin/users${search ? `?search=${encodeURIComponent(search)}` : ''}`),

  toggleUserStatus: (userId: string) =>
    apiClient.request<{ message: string; status: string }>(`/admin/users/${userId}/toggle-status`, {
      method: 'POST',
    }),

  getAdminUserDetail: (userId: string) =>
    apiClient.request<{
      user: User;
      wallet: Wallet;
      transactions: Transaction[];
      completions: any[];
      surveyHistory: any[];
      withdrawals: Withdrawal[];
    }>(`/admin/users/${userId}/detail`),

  getAdminTasks: () => apiClient.request<{ tasks: TaskItem[] }>('/admin/tasks'),

  createAdminTask: (task: Partial<TaskItem>) =>
    apiClient.request<{ message: string; task: TaskItem }>('/admin/tasks', {
      method: 'POST',
      body: JSON.stringify(task),
    }),

  updateAdminTask: (id: string, task: Partial<TaskItem>) =>
    apiClient.request<{ message: string; task: TaskItem }>(`/admin/tasks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(task),
    }),

  deleteAdminTask: (id: string) =>
    apiClient.request<{ message: string }>(`/admin/tasks/${id}`, {
      method: 'DELETE',
    }),

  getAdminSurveys: () => apiClient.request<{ surveys: SurveyItem[] }>('/admin/surveys'),

  createAdminSurvey: (survey: Partial<SurveyItem>) =>
    apiClient.request<{ message: string; survey: SurveyItem }>('/admin/surveys', {
      method: 'POST',
      body: JSON.stringify(survey),
    }),

  updateAdminSurvey: (id: string, survey: Partial<SurveyItem>) =>
    apiClient.request<{ message: string; survey: SurveyItem }>(`/admin/surveys/${id}`, {
      method: 'PUT',
      body: JSON.stringify(survey),
    }),

  deleteAdminSurvey: (id: string) =>
    apiClient.request<{ message: string }>(`/admin/surveys/${id}`, {
      method: 'DELETE',
    }),

  getAdminWithdrawals: () => apiClient.request<{ withdrawals: Withdrawal[] }>('/admin/withdrawals'),

  updateWithdrawalStatus: (id: string, status: string, adminNote?: string) =>
    apiClient.request<{ message: string; withdrawal: Withdrawal }>(`/admin/withdrawals/${id}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, adminNote }),
    }),

  updateAdminSettings: (settings: Partial<AppSettings>) =>
    apiClient.request<{ message: string; settings: AppSettings }>('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  // Transactions
  getTransactions: () => apiClient.request<{ transactions: Transaction[] }>('/transactions'),

  // Password change
  changePassword: (body: any) =>
    apiClient.request<{ message: string }>('/auth/profile', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // Admin aliases
  getAdminDashboard: async () => {
    const metrics = await apiClient.getAdminMetrics();
    return {
      stats: {
        totalUsers: metrics.totalUsers,
        totalRewardsDistributed: metrics.totalRewardsDistributedRs,
        pendingWithdrawalsCount: metrics.pendingWithdrawalsCount,
        pendingWithdrawalsAmount: metrics.pendingWithdrawalsAmountRs,
        totalTasksCompleted: metrics.activeTasksCount * 4,
        totalSurveysCompleted: metrics.activeSurveysCount * 6,
        totalWithdrawnPaid: metrics.paidWithdrawalsAmountRs,
      },
    };
  },
  getAdminSettings: () => apiClient.getSettings(),
  adminAdjustBalance: (body: { userId: string; amount: number; reason: string }) =>
    apiClient.request<{ message: string; wallet: Wallet }>(`/admin/users/${body.userId}/adjust-balance`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  adminUpdateUserStatus: (userId: string, status: string) =>
    apiClient.request<{ message: string; status: string }>(`/admin/users/${userId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status }),
    }),
  adminCreateTask: (task: Partial<TaskItem>) => apiClient.createAdminTask(task),
  adminDeleteTask: (id: string) => apiClient.deleteAdminTask(id),
  adminCreateSurvey: (survey: Partial<SurveyItem>) => apiClient.createAdminSurvey(survey),
  adminDeleteSurvey: (id: string) => apiClient.deleteAdminSurvey(id),
  adminUpdateWithdrawal: (id: string, body: { status: string; adminNote?: string }) =>
    apiClient.updateWithdrawalStatus(id, body.status, body.adminNote),
  adminUpdateSettings: (settings: any) => apiClient.updateAdminSettings(settings),
};

