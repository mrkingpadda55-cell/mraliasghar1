import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, CheckCircle2, Lock, HelpCircle, FileText, Phone, Mail, Youtube, Instagram, Facebook, Share2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { theme } = useAuth();
  const isDark = theme === 'dark';

  return (
    <footer
      id="app-footer"
      className={`border-t transition-colors ${
        isDark ? 'bg-slate-950 border-slate-800/80 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand & Integrity */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-slate-950" />
              </div>
              <span className="font-extrabold text-lg text-slate-100 bg-gradient-to-r from-amber-400 to-emerald-400 bg-clip-text text-transparent">
                MR Aliasghar
              </span>
            </div>
            <p className="text-xs leading-relaxed max-w-md">
              A legitimate rewards and survey platform designed for Pakistan. We do not provide artificial clicks or unverified earnings. Rewards in Pakistani Rupees (Rs) are credited only after genuine completion and verification of configured tasks and surveys.
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold pt-1">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-4 h-4" /> 100% Genuine Rs Rewards
              </span>
              <span className="flex items-center gap-1.5 text-amber-400">
                <Lock className="w-4 h-4" /> Secure Server Balance
              </span>
            </div>
          </div>

          {/* Col 2: Official Social Channels */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">Official Socials</p>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="https://youtube.com/@aliasgharpadda?si=OZyKzuTJ8J_yT4Iq"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-slate-300 hover:text-rose-400 transition-colors"
                >
                  <Youtube className="w-4 h-4 text-rose-500 shrink-0" />
                  <span className="font-medium">YouTube Channel</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.tiktok.com/@hafizgulaamabbasqadri?_r=1&_t=ZS-99vanqLYWAe"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-slate-300 hover:text-cyan-400 transition-colors"
                >
                  <Share2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="font-medium">TikTok ID</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/mrkingofnarowal?stkn=dXJzN2EwMzRid21l"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-slate-300 hover:text-pink-400 transition-colors"
                >
                  <Instagram className="w-4 h-4 text-pink-500 shrink-0" />
                  <span className="font-medium">Instagram Profile</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.facebook.com/share/16CrChpyJjc/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-slate-300 hover:text-blue-400 transition-colors"
                >
                  <Facebook className="w-4 h-4 text-blue-500 shrink-0" />
                  <span className="font-medium">Facebook Page</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Supported Payouts */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">Supported Payouts</p>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span className="font-semibold text-slate-200">JazzCash</span>
                <span className="text-[10px] text-slate-500">Mobile Account</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="font-semibold text-slate-200">Easypaisa</span>
                <span className="text-[10px] text-slate-500">Mobile Account</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="font-semibold text-slate-200">Binance</span>
                <span className="text-[10px] text-slate-500">Binance Pay ID</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Support */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">Quick Links & Support</p>
            <div className="flex flex-col space-y-2 text-xs">
              <button
                onClick={() => onNavigate('/help')}
                className="text-left hover:text-amber-400 transition-colors flex items-center gap-1.5"
              >
                <HelpCircle className="w-3.5 h-3.5" /> Help & FAQ
              </button>
              <button
                onClick={() => onNavigate('/terms')}
                className="text-left hover:text-amber-400 transition-colors flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5" /> Terms of Service
              </button>
              <button
                onClick={() => onNavigate('/privacy')}
                className="text-left hover:text-amber-400 transition-colors flex items-center gap-1.5"
              >
                <Lock className="w-3.5 h-3.5" /> Privacy Policy
              </button>
              <div className="pt-2 border-t border-slate-800 text-[11px] space-y-1">
                <p className="flex items-center gap-1.5 text-slate-400">
                  <Mail className="w-3 h-3 text-amber-400" /> support@mraliasghar.com
                </p>
                <p className="flex items-center gap-1.5 text-slate-400">
                  <Phone className="w-3 h-3 text-emerald-400" /> +92 300 1234567
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <p>© 2026 MR Aliasghar. All rights reserved.</p>
          <p>Currency: Pakistani Rupee (Rs) • Transparent & Verified Rewards</p>
        </div>
      </div>
    </footer>
  );
};
