import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  CheckSquare,
  FileText,
  Gift,
  Wallet,
  CreditCard,
  History,
  Users,
  HelpCircle,
  ShieldAlert,
  LogOut,
  User,
  ChevronRight,
  Crown,
} from 'lucide-react';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPath, onNavigate }) => {
  const { user, wallet, logout, theme } = useAuth();
  const isDark = theme === 'dark';

  if (!user) return null;

  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Tasks', path: '/tasks', icon: CheckSquare },
    { label: 'MR King AI Logo', path: '/mrking-logo', icon: Crown, badge: 'Rs 60' },
    { label: 'Surveys', path: '/surveys', icon: FileText },
    { label: 'Daily Reward', path: '/daily-reward', icon: Gift, badge: 'Daily' },
    { label: 'Wallet', path: '/wallet', icon: Wallet },
    { label: 'Withdraw', path: '/withdraw', icon: CreditCard },
    { label: 'Transactions', path: '/transactions', icon: History },
    { label: 'Referrals', path: '/referrals', icon: Users },
    { label: 'Help & FAQ', path: '/help', icon: HelpCircle },
  ];

  return (
    <aside
      id="desktop-sidebar"
      className={`hidden lg:flex flex-col w-64 shrink-0 border-r min-h-[calc(100vh-4rem)] p-4 transition-colors ${
        isDark ? 'bg-slate-950/60 border-slate-800/80 text-slate-200' : 'bg-slate-50/60 border-slate-200 text-slate-800'
      }`}
    >
      {/* Wallet Balance Summary Card */}
      <div
        onClick={() => onNavigate('/wallet')}
        className={`p-3.5 rounded-xl border mb-6 cursor-pointer transition-all hover:border-amber-500/50 group ${
          isDark ? 'bg-gradient-to-br from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span>Available Balance</span>
          <Wallet className="w-3.5 h-3.5 text-amber-400" />
        </div>
        <div className="text-xl font-black text-amber-400">
          Rs {(wallet?.availableBalance ?? 0).toFixed(2)}
        </div>
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/40 text-[11px] text-slate-400">
          <span>Pending: Rs {(wallet?.pendingWithdrawal ?? 0).toFixed(2)}</span>
          <span className="text-emerald-400 group-hover:translate-x-0.5 transition-transform flex items-center">
            Wallet <ChevronRight className="w-3 h-3" />
          </span>
        </div>
      </div>

      {/* Nav List */}
      <div className="space-y-1 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPath === item.path;

          return (
            <button
              key={item.path}
              id={`sidebar-link-${item.path.replace('/', '')}`}
              onClick={() => onNavigate(item.path)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 font-semibold border border-amber-500/30 shadow-sm shadow-amber-500/5'
                  : isDark
                  ? 'hover:bg-slate-900 text-slate-400 hover:text-slate-100'
                  : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Admin Navigation Item */}
        {user.role === 'admin' && (
          <button
            id="sidebar-link-admin"
            onClick={() => onNavigate('/admin')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all mt-4 ${
              currentPath === '/admin'
                ? 'bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40'
                : 'text-emerald-400/90 hover:bg-emerald-500/10 border border-emerald-500/20'
            }`}
          >
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-4 h-4 text-emerald-400" />
              <span>Admin Panel</span>
            </div>
            <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-500/30 text-emerald-300">
              Admin
            </span>
          </button>
        )}
      </div>

      {/* User Footer Profile in Sidebar */}
      <div className={`pt-4 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
        <div className="flex items-center justify-between">
          <div
            onClick={() => onNavigate('/profile')}
            className="flex items-center gap-2.5 cursor-pointer overflow-hidden group"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold text-xs shrink-0 group-hover:scale-105 transition-transform">
              <User className="w-4 h-4" />
            </div>
            <div className="truncate">
              <p className="text-xs font-bold truncate group-hover:text-amber-400 transition-colors">{user.name}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
            </div>
          </div>

          <button
            id="sidebar-logout-btn"
            onClick={() => {
              logout();
              onNavigate('/');
            }}
            title="Log Out"
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
