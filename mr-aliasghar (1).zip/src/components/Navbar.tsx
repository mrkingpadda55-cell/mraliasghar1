import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Wallet as WalletIcon,
  Sun,
  Moon,
  Menu,
  X,
  ShieldCheck,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Gift,
  LayoutDashboard,
  CheckSquare,
  FileText,
  CreditCard,
  Settings,
  Users,
  Crown,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const { user, wallet, theme, toggleTheme, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const handleNav = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  };

  const isDark = theme === 'dark';

  return (
    <nav
      id="main-navbar"
      className={`sticky top-0 z-40 w-full border-b backdrop-blur-md transition-colors ${
        isDark
          ? 'bg-slate-950/90 border-slate-800 text-slate-100'
          : 'bg-white/90 border-slate-200 text-slate-900'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div
            id="brand-logo-btn"
            onClick={() => handleNav(user ? '/dashboard' : '/')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-emerald-500 flex items-center justify-center shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight bg-gradient-to-r from-amber-400 via-amber-200 to-emerald-400 bg-clip-text text-transparent">
                  MR Aliasghar
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  VIP
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium hidden sm:block">
                Legitimate Rewards & Surveys
              </p>
            </div>
          </div>

          {/* Desktop Right Actions */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <>
                {/* Available Balance Pill */}
                <button
                  id="nav-balance-btn"
                  onClick={() => handleNav('/wallet')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-semibold transition-all hover:scale-102 ${
                    isDark
                      ? 'bg-slate-900 border-amber-500/30 text-amber-400 hover:border-amber-500/60'
                      : 'bg-amber-50 border-amber-300 text-amber-900 hover:border-amber-400'
                  }`}
                >
                  <WalletIcon className="w-4 h-4 text-emerald-400" />
                  <span>Rs {(wallet?.availableBalance ?? 0).toFixed(2)}</span>
                </button>

                {/* MR King AI Logo Task Shortcut */}
                <button
                  id="nav-mrking-logo-btn"
                  onClick={() => handleNav('/mrking-logo')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border border-amber-400/40 bg-gradient-to-r from-amber-500/20 to-emerald-500/10 text-amber-300 hover:border-amber-400 transition-all shadow-sm"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>MR King Logo</span>
                  <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.5 rounded-full">Rs 60</span>
                </button>

                {/* Daily Reward Shortcut */}
                <button
                  id="nav-daily-reward-btn"
                  onClick={() => handleNav('/daily-reward')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    isDark
                      ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800'
                      : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <Gift className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                  <span>Daily Reward</span>
                </button>

                {/* User Dropdown */}
                <div className="relative">
                  <button
                    id="nav-user-dropdown-btn"
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm transition-colors ${
                      isDark
                        ? 'bg-slate-900 border-slate-800 hover:bg-slate-800 text-slate-200'
                        : 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs border border-amber-500/30">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-medium max-w-[120px] truncate">{user.name}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  {userDropdownOpen && (
                    <div
                      id="nav-dropdown-menu"
                      className={`absolute right-0 mt-2 w-56 rounded-xl border shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 ${
                        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
                      }`}
                    >
                      <div className="px-4 py-2 border-b border-slate-800/50">
                        <p className="text-xs font-semibold text-slate-400">Signed in as</p>
                        <p className="text-sm font-bold truncate">{user.email}</p>
                        {user.role === 'admin' && (
                          <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            Administrator
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => handleNav('/dashboard')}
                        className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 hover:bg-amber-500/10 hover:text-amber-400"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        Dashboard
                      </button>
                      <button
                        onClick={() => handleNav('/profile')}
                        className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 hover:bg-amber-500/10 hover:text-amber-400"
                      >
                        <UserIcon className="w-4 h-4" />
                        Profile Settings
                      </button>
                      <button
                        onClick={() => handleNav('/wallet')}
                        className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 hover:bg-amber-500/10 hover:text-amber-400"
                      >
                        <WalletIcon className="w-4 h-4" />
                        Wallet & Withdraw
                      </button>
                      <button
                        onClick={() => handleNav('/referrals')}
                        className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 hover:bg-amber-500/10 hover:text-amber-400"
                      >
                        <Users className="w-4 h-4" />
                        Referral Program
                      </button>

                      {user.role === 'admin' && (
                        <button
                          onClick={() => handleNav('/admin')}
                          className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 text-emerald-400 font-semibold hover:bg-emerald-500/10"
                        >
                          <Settings className="w-4 h-4" />
                          Admin Panel
                        </button>
                      )}

                      <div className="border-t border-slate-800/50 mt-1 pt-1">
                        <button
                          onClick={() => {
                            logout();
                            handleNav('/');
                          }}
                          className="w-full text-left px-4 py-2 text-sm flex items-center gap-2 text-rose-400 hover:bg-rose-500/10"
                        >
                          <LogOut className="w-4 h-4" />
                          Log Out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="nav-login-btn"
                  onClick={() => handleNav('/login')}
                  className={`px-4 py-1.5 text-sm font-semibold rounded-lg transition-colors ${
                    isDark ? 'text-slate-200 hover:text-white' : 'text-slate-700 hover:text-black'
                  }`}
                >
                  Log In
                </button>
                <button
                  id="nav-register-btn"
                  onClick={() => handleNav('/register')}
                  className="px-4 py-1.5 text-sm font-bold rounded-lg bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity"
                >
                  Register
                </button>
              </div>
            )}

            {/* Theme Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className={`p-2 rounded-lg border transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800 text-amber-400 hover:bg-slate-800' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

          {/* Mobile Right Controls */}
          <div className="flex items-center gap-2 md:hidden">
            {user && (
              <div
                onClick={() => handleNav('/wallet')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-bold ${
                  isDark ? 'bg-slate-900 border-amber-500/30 text-amber-400' : 'bg-amber-50 border-amber-200 text-amber-900'
                }`}
              >
                <span>Rs {(wallet?.availableBalance ?? 0).toFixed(0)}</span>
              </div>
            )}

            <button
              onClick={toggleTheme}
              className={`p-1.5 rounded-lg border ${
                isDark ? 'bg-slate-900 border-slate-800 text-amber-400' : 'bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-1.5 rounded-lg border ${
                isDark ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer-menu"
          className={`md:hidden border-b px-4 py-4 space-y-2 animate-in slide-in-from-top duration-200 ${
            isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          {user ? (
            <>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/40">
                <div>
                  <p className="font-bold text-sm">{user.name}</p>
                  <p className="text-xs text-slate-400">{user.email}</p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Balance</span>
                  <p className="text-sm font-extrabold text-amber-400">Rs {(wallet?.availableBalance ?? 0).toFixed(2)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => handleNav('/dashboard')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/dashboard' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </button>
                <button
                  onClick={() => handleNav('/tasks')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/tasks' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" /> Tasks
                </button>
                <button
                  onClick={() => handleNav('/mrking-logo')}
                  className={`p-2 rounded-lg text-left text-xs font-bold flex items-center justify-between border ${
                    currentPath === '/mrking-logo' ? 'bg-amber-500/20 border-amber-400 text-amber-300' : 'border-amber-500/30 text-amber-400 bg-amber-500/5'
                  }`}
                >
                  <span className="flex items-center gap-2"><Crown className="w-4 h-4 text-amber-400" /> MR King Logo</span>
                  <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.2 rounded-full">Rs 60</span>
                </button>
                <button
                  onClick={() => handleNav('/surveys')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/surveys' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <FileText className="w-4 h-4" /> Surveys
                </button>
                <button
                  onClick={() => handleNav('/daily-reward')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/daily-reward' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <Gift className="w-4 h-4 text-amber-400" /> Daily Reward
                </button>
                <button
                  onClick={() => handleNav('/wallet')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/wallet' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <WalletIcon className="w-4 h-4" /> Wallet
                </button>
                <button
                  onClick={() => handleNav('/withdraw')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/withdraw' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <CreditCard className="w-4 h-4" /> Withdraw
                </button>
                <button
                  onClick={() => handleNav('/referrals')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/referrals' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <Users className="w-4 h-4" /> Referrals
                </button>
                <button
                  onClick={() => handleNav('/profile')}
                  className={`p-2 rounded-lg text-left text-xs font-semibold flex items-center gap-2 border ${
                    currentPath === '/profile' ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' : 'border-slate-800'
                  }`}
                >
                  <UserIcon className="w-4 h-4" /> Profile
                </button>
              </div>

              {user.role === 'admin' && (
                <button
                  onClick={() => handleNav('/admin')}
                  className="w-full py-2 px-3 rounded-lg text-xs font-bold text-center bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center gap-2"
                >
                  <Settings className="w-4 h-4" /> Go to Admin Dashboard
                </button>
              )}

              <button
                onClick={() => {
                  logout();
                  handleNav('/');
                }}
                className="w-full py-2 px-3 rounded-lg text-xs font-bold text-center bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" /> Log Out
              </button>
            </>
          ) : (
            <div className="space-y-2">
              <button
                onClick={() => handleNav('/login')}
                className="w-full py-2.5 rounded-lg text-sm font-semibold border border-slate-700 text-center"
              >
                Log In
              </button>
              <button
                onClick={() => handleNav('/register')}
                className="w-full py-2.5 rounded-lg text-sm font-bold bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 text-center"
              >
                Register Free
              </button>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};
