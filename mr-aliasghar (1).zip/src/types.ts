export type UserRole = 'admin' | 'user';
export type UserStatus = 'active' | 'suspended' | 'banned';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  status: UserStatus;
  referralCode: string;
  referredBy?: string | null;
  createdAt: string;
  lastLogin: string;
}

export interface Wallet {
  userId: string;
  availableBalance: number; // In Rs
  totalEarned: number;      // In Rs
  totalWithdrawn: number;   // In Rs
  pendingWithdrawal: number;// In Rs
  updatedAt: string;
}

export type PlatformType = 'YouTube' | 'TikTok' | 'Facebook' | 'Instagram' | 'Website Visit' | 'AI Design' | 'Other';
export type VerificationMethod = 'timed_visit' | 'manual_review' | 'action_confirmation' | 'image_upload';

export interface TaskItem {
  id: string;
  title: string;
  platform: PlatformType;
  description: string;
  destinationUrl: string;
  rewardRs: number;
  dailyLimit: number;
  totalLimit: number;
  completionsCount: number;
  startDate: string;
  endDate: string;
  status: 'active' | 'inactive';
  isActive?: boolean;
  verificationMethod: VerificationMethod;
  minDwellSeconds: number;
  requiresProof: boolean;
  proofPrompt?: string;
  proofImageUrl?: string;
  isCompletedByUser?: boolean;
}

export interface TaskCompletion {
  id: string;
  taskId: string;
  taskTitle: string;
  userId: string;
  rewardRs: number;
  completedAt: string;
  verificationStatus: 'verified' | 'pending' | 'rejected';
  proofText?: string;
  proofImageUrl?: string;
}

export type QuestionType = 'multiple_choice' | 'yes_no' | 'short_answer';

export interface SurveyQuestion {
  id: string;
  question: string;
  type: QuestionType;
  options?: string[];
  required: boolean;
}

export interface SurveyItem {
  id: string;
  title: string;
  description: string;
  rewardRs: number;
  durationMinutes: number;
  maxParticipants: number;
  completedCount: number;
  status: 'active' | 'inactive';
  questions: SurveyQuestion[];
  createdAt: string;
  isCompletedByUser?: boolean;
}

export interface SurveyResponse {
  id: string;
  surveyId: string;
  surveyTitle: string;
  userId: string;
  answers: Record<string, string | string[]>;
  rewardRs: number;
  submittedAt: string;
}

export type TransactionType =
  | 'Survey Reward'
  | 'Daily Reward'
  | 'Task Reward'
  | 'Referral Reward'
  | 'Withdrawal'
  | 'Withdrawal Reversal'
  | 'Admin Adjustment';

export type TransactionStatus = 'completed' | 'pending' | 'reversed' | 'cancelled';

export interface Transaction {
  id: string;
  userId: string;
  amount: number; // positive for earnings/reversals, negative for withdrawals
  type: TransactionType;
  status: TransactionStatus;
  description: string;
  createdAt: string;
}

export type PaymentMethod = 'JazzCash' | 'Easypaisa' | 'Binance';

export type WithdrawalStatus =
  | 'Pending'
  | 'Approved'
  | 'Processing'
  | 'Paid'
  | 'Rejected'
  | 'Cancelled';

export interface WithdrawalDetails {
  accountHolderName?: string;
  mobileNumber?: string;
  binancePayId?: string;
  notes?: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  amount: number;
  fee: number;
  netAmount: number;
  paymentMethod: PaymentMethod;
  accountDetails: WithdrawalDetails;
  status: WithdrawalStatus;
  adminNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DailyRewardStatus {
  rewardRs: number;
  canClaim: boolean;
  lastClaimTime: string | null;
  nextClaimTime: string | null;
  secondsRemaining: number;
}

export interface ReferralStats {
  referralCode: string;
  referralLink: string;
  totalReferrals: number;
  totalReferralEarnings: number;
  rewardPerReferral: number;
  referrals: Array<{
    id: string;
    referredUserName: string;
    joinedAt: string;
    rewardRs: number;
    status: string;
  }>;
}

export interface AppSettings {
  websiteName: string;
  currencySymbol: string;
  minWithdrawal: number;
  maxWithdrawal: number;
  withdrawalFeePercent: number;
  referralRewardRs: number;
  dailyRewardRs: number;
  availableWithdrawalMethods: PaymentMethod[];
  supportEmail: string;
  supportPhone: string;
  termsUpdated: string;
}

export interface AdminMetrics {
  totalUsers: number;
  activeUsers: number;
  totalRewardsDistributedRs: number;
  pendingWithdrawalsCount: number;
  pendingWithdrawalsAmountRs: number;
  paidWithdrawalsCount: number;
  paidWithdrawalsAmountRs: number;
  activeSurveysCount: number;
  activeTasksCount: number;
  totalTransactionsCount: number;
  totalWithdrawnPaid?: number;
}

export type PlatformSettings = AppSettings & {
  dailyRewardAmount?: number;
  referralRewardAmount?: number;
  maintenanceMode?: boolean;
};

export type ReferralSummary = ReferralStats;
