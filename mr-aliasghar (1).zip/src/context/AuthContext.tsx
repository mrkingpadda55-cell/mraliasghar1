import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Wallet, AppSettings } from '../types';
import { apiClient } from '../api/client';

interface AuthContextType {
  user: User | null;
  wallet: Wallet | null;
  settings: AppSettings | null;
  isLoading: boolean;
  loading: boolean;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  login: (credentials: any) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('mra_theme', next);
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('mra_theme') as 'dark' | 'light' | null;
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  const refreshUser = async () => {
    try {
      const token = apiClient.getToken();
      if (!token) {
        setUser(null);
        setWallet(null);
        return;
      }
      const data = await apiClient.getMe();
      setUser(data.user);
      setWallet(data.wallet);
    } catch (err) {
      console.error('Session verification error:', err);
      apiClient.removeToken();
      setUser(null);
      setWallet(null);
    }
  };

  useEffect(() => {
    async function init() {
      try {
        const [settingsRes] = await Promise.allSettled([
          apiClient.getSettings(),
        ]);
        if (settingsRes.status === 'fulfilled') {
          setSettings(settingsRes.value.settings);
        }
        await refreshUser();
      } finally {
        setIsLoading(false);
      }
    }
    init();
  }, []);

  const login = async (credentials: any) => {
    const res = await apiClient.login(credentials);
    apiClient.setToken(res.token);
    setUser(res.user);
    setWallet(res.wallet);
  };

  const register = async (userData: any) => {
    const res = await apiClient.register(userData);
    apiClient.setToken(res.token);
    setUser(res.user);
    setWallet(res.wallet);
  };

  const logout = () => {
    apiClient.removeToken();
    setUser(null);
    setWallet(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        wallet,
        settings,
        isLoading,
        loading: isLoading,
        theme,
        toggleTheme,
        login,
        register,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
