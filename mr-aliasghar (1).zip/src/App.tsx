import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';

// Pages
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { DashboardPage } from './pages/DashboardPage';
import { TasksPage } from './pages/TasksPage';
import { SurveysPage } from './pages/SurveysPage';
import { DailyRewardPage } from './pages/DailyRewardPage';
import { WalletPage } from './pages/WalletPage';
import { WithdrawPage } from './pages/WithdrawPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { ReferralsPage } from './pages/ReferralsPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminPage } from './pages/AdminPage';
import { HelpPage } from './pages/HelpPage';
import { MrKingLogoPage } from './pages/MrKingLogoPage';
import { NotFoundPage } from './pages/NotFoundPage';
import brandBg from './assets/images/mraliasghar_brand_bg_1790026816381.jpg';

const AppContent: React.FC = () => {
  const { user, loading, theme } = useAuth();
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });

  // Keep in sync with browser popstate
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-emerald-400 animate-pulse flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-amber-500/20">
          M
        </div>
        <p className="text-xs font-semibold text-slate-400 mt-4 tracking-wider uppercase">
          Loading MR Aliasghar...
        </p>
      </div>
    );
  }

  // Determine if path is private
  const privateRoutes = [
    '/dashboard',
    '/tasks',
    '/surveys',
    '/daily-reward',
    '/wallet',
    '/withdraw',
    '/transactions',
    '/referrals',
    '/profile',
    '/admin',
    '/mrking-logo',
  ];

  const isPrivate = privateRoutes.includes(currentPath);

  // Fallback to login if accessing private route while unauthenticated
  let effectivePath = currentPath;
  if (!user && isPrivate) {
    effectivePath = '/login';
  }

  // Render view component
  const renderView = () => {
    switch (effectivePath) {
      case '/':
        return <LandingPage onNavigate={navigate} />;
      case '/login':
        return <LoginPage onNavigate={navigate} />;
      case '/register':
        return <RegisterPage onNavigate={navigate} />;
      case '/forgot-password':
        return <ForgotPasswordPage onNavigate={navigate} />;
      case '/dashboard':
        return <DashboardPage onNavigate={navigate} />;
      case '/tasks':
        return <TasksPage onNavigate={navigate} />;
      case '/surveys':
        return <SurveysPage onNavigate={navigate} />;
      case '/daily-reward':
        return <DailyRewardPage onNavigate={navigate} />;
      case '/wallet':
        return <WalletPage onNavigate={navigate} />;
      case '/withdraw':
        return <WithdrawPage onNavigate={navigate} />;
      case '/transactions':
        return <TransactionsPage onNavigate={navigate} />;
      case '/referrals':
        return <ReferralsPage onNavigate={navigate} />;
      case '/profile':
        return <ProfilePage onNavigate={navigate} />;
      case '/mrking-logo':
        return <MrKingLogoPage onNavigate={navigate} />;
      case '/admin':
        if (user?.role !== 'admin') {
          return (
            <div className="max-w-md mx-auto px-4 py-16 text-center">
              <h2 className="text-xl font-bold text-rose-400 mb-2">Access Denied</h2>
              <p className="text-xs text-slate-400 mb-6">
                You do not have administrative privileges to view this section.
              </p>
              <button
                onClick={() => navigate('/dashboard')}
                className="px-5 py-2.5 rounded-xl font-bold bg-amber-500 text-slate-950 text-xs"
              >
                Return to Dashboard
              </button>
            </div>
          );
        }
        return <AdminPage onNavigate={navigate} />;
      case '/help':
        return <HelpPage initialTab="faq" onNavigate={navigate} />;
      case '/terms':
        return <HelpPage initialTab="terms" onNavigate={navigate} />;
      case '/privacy':
        return <HelpPage initialTab="privacy" onNavigate={navigate} />;
      default:
        return <NotFoundPage onNavigate={navigate} />;
    }
  };

  const showSidebar = user && isPrivate && effectivePath !== '/' && effectivePath !== '/login' && effectivePath !== '/register';

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors relative selection:bg-amber-500 selection:text-slate-950 ${
        theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-900 text-slate-100'
      }`}
    >
      {/* MR Aliasghar Brand Backdrop Layer replacing plain background color */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <img
          src={brandBg}
          alt="MR Aliasghar Brand Backdrop"
          className="w-full h-full object-cover opacity-25 filter brightness-75 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/85 to-slate-950/95" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar currentPath={effectivePath} onNavigate={navigate} />

        <div className="flex-1 flex w-full">
          {showSidebar && <Sidebar currentPath={effectivePath} onNavigate={navigate} />}

          <main className="flex-1 min-w-0 pb-16 lg:pb-8">
            {renderView()}
          </main>
        </div>

        <Footer onNavigate={navigate} />

        {showSidebar && <MobileBottomNav currentPath={effectivePath} onNavigate={navigate} />}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
