import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { DailyRewardStatus } from '../types';
import confetti from 'canvas-confetti';
import {
  Gift,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Calendar,
  Lock,
  ArrowRight,
} from 'lucide-react';

interface DailyRewardPageProps {
  onNavigate: (path: string) => void;
}

export const DailyRewardPage: React.FC<DailyRewardPageProps> = ({ onNavigate }) => {
  const { wallet, refreshUser, theme } = useAuth();
  const [status, setStatus] = useState<DailyRewardStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getDailyRewardStatus();
      setStatus(res);
      setSecondsRemaining(res.secondsRemaining);
    } catch (err) {
      console.error('Error fetching daily reward status:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  // Tick seconds remaining
  useEffect(() => {
    if (secondsRemaining <= 0) return;
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          fetchStatus();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [secondsRemaining]);

  const handleClaim = async () => {
    try {
      setClaiming(true);
      setErrorMsg(null);
      setSuccessMsg(null);

      const res = await apiClient.claimDailyReward();
      setSuccessMsg(res.message);

      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });

      await refreshUser();
      await fetchStatus();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to claim daily reward.');
    } finally {
      setClaiming(false);
    }
  };

  const formatCountdown = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const isDark = theme === 'dark';
  const canClaim = status?.canClaim && secondsRemaining === 0;

  return (
    <div id="daily-reward-page" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Guaranteed 24-Hour Streak Allowance</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-100">
          Daily Check-in Reward
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
          Log in every 24 hours to claim your authentic reward credited directly to your Pakistani Rupee balance.
        </p>
      </div>

      {/* Main Reward Card */}
      <div
        className={`p-8 sm:p-12 rounded-3xl border text-center shadow-xl relative overflow-hidden ${
          isDark ? 'bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-emerald-400 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-500/20">
          <Gift className="w-10 h-10 text-slate-950" />
        </div>

        <div className="space-y-1 mb-6">
          <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">Today's Reward</span>
          <div className="text-4xl sm:text-5xl font-black text-amber-400">
            Rs {(status?.rewardRs ?? 2).toFixed(2)}
          </div>
        </div>

        {errorMsg && (
          <div className="max-w-md mx-auto mb-6 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="max-w-md mx-auto mb-6 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Claim Action or Countdown Timer */}
        <div className="max-w-sm mx-auto">
          {canClaim ? (
            <button
              id="claim-daily-reward-btn"
              onClick={handleClaim}
              disabled={claiming}
              className="w-full py-4 rounded-2xl font-black text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-xl shadow-amber-500/25 hover:scale-102 transition-all flex items-center justify-center gap-2 text-base disabled:opacity-50"
            >
              {claiming ? 'Verifying on Server...' : `Claim Rs ${(status?.rewardRs ?? 2).toFixed(2)} Now`}
            </button>
          ) : (
            <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/60 space-y-2">
              <span className="text-xs text-slate-400 font-semibold flex items-center justify-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Next Claim Available In:
              </span>
              <div className="font-mono text-3xl font-extrabold text-slate-200">
                {formatCountdown(secondsRemaining)}
              </div>
              <p className="text-[11px] text-slate-500">
                You can claim once every 24 hours. Verification is enforced server-side.
              </p>
            </div>
          )}
        </div>

        {/* Details Grid */}
        <div className="mt-8 pt-8 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto text-left text-xs">
          <div className="p-3.5 rounded-xl border border-slate-800/60 bg-slate-950/40">
            <span className="text-slate-500 block mb-0.5">Last Claim Time</span>
            <span className="font-medium text-slate-200">
              {status?.lastClaimTime ? new Date(status.lastClaimTime).toLocaleString() : 'Never claimed yet'}
            </span>
          </div>

          <div className="p-3.5 rounded-xl border border-slate-800/60 bg-slate-950/40">
            <span className="text-slate-500 block mb-0.5">Next Available Claim</span>
            <span className="font-medium text-slate-200">
              {status?.nextClaimTime ? new Date(status.nextClaimTime).toLocaleString() : 'Ready right now'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
