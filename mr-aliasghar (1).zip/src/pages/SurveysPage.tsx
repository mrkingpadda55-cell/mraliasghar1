import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { SurveyItem } from '../types';
import confetti from 'canvas-confetti';
import {
  FileText,
  Clock,
  Users,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  HelpCircle,
  X,
} from 'lucide-react';

interface SurveysPageProps {
  onNavigate: (path: string) => void;
}

export const SurveysPage: React.FC<SurveysPageProps> = ({ onNavigate }) => {
  const { refreshUser, theme } = useAuth();
  const [surveys, setSurveys] = useState<SurveyItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Survey Modal
  const [activeSurvey, setActiveSurvey] = useState<SurveyItem | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchSurveys = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getSurveys();
      setSurveys(res.surveys);
    } catch (err) {
      console.error('Error fetching surveys:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSurveys();
  }, []);

  const handleStartSurvey = (survey: SurveyItem) => {
    setActiveSurvey(survey);
    setAnswers({});
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value,
    }));
  };

  const handleSubmitSurvey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSurvey) return;

    // Validate required questions
    for (const q of activeSurvey.questions) {
      if (q.required && (!answers[q.id] || answers[q.id].trim().length === 0)) {
        setErrorMsg(`Please answer question: "${q.question}"`);
        return;
      }
    }

    try {
      setSubmitting(true);
      setErrorMsg(null);
      const res = await apiClient.submitSurvey(activeSurvey.id, answers);
      setSuccessMsg(res.message);

      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });

      await refreshUser();
      await fetchSurveys();

      setTimeout(() => {
        setActiveSurvey(null);
      }, 2000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Survey submission failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const isDark = theme === 'dark';

  return (
    <div id="surveys-page" className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-2">
          <FileText className="w-3.5 h-3.5" />
          <span>Verified Market Research & Opinion Studies</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
          Consumer Research Surveys
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
          Share your authentic opinions regarding consumer trends, retail habits, and financial services in Pakistan. Rewards in Rs are added straight to your balance upon validated submission.
        </p>
      </div>

      {/* Surveys List */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">
          Loading active research surveys...
        </div>
      ) : surveys.length === 0 ? (
        <div className="text-center py-16 p-8 rounded-3xl border border-slate-800 bg-slate-900/30">
          <p className="text-sm font-semibold text-slate-300">No active surveys available at this moment.</p>
          <p className="text-xs text-slate-500 mt-1">Check back shortly as new consumer studies are published regularly.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {surveys.map((survey) => (
            <div
              key={survey.id}
              className={`p-6 rounded-2xl border flex flex-col justify-between transition-all ${
                survey.isCompletedByUser
                  ? isDark
                    ? 'bg-slate-950/40 border-slate-800/50 opacity-70'
                    : 'bg-slate-100/50 border-slate-200 opacity-70'
                  : isDark
                  ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/40'
                  : 'bg-white border-slate-200 shadow-sm hover:border-amber-400'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    {survey.questions.length} Questions
                  </span>

                  <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    +Rs {survey.rewardRs.toFixed(2)}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-100 line-clamp-1 mb-1.5">{survey.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed mb-4">
                  {survey.description}
                </p>

                <div className="flex items-center gap-4 text-[11px] text-slate-500 mb-5">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> ~{survey.durationMinutes} mins
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" /> {survey.completedCount}/{survey.maxParticipants} slots
                  </span>
                </div>
              </div>

              {survey.isCompletedByUser ? (
                <div className="w-full py-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 font-bold text-xs flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Survey Completed
                </div>
              ) : (
                <button
                  id={`start-survey-btn-${survey.id}`}
                  onClick={() => handleStartSurvey(survey)}
                  className="w-full py-2.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-sm hover:opacity-95 transition-opacity flex items-center justify-center gap-2 text-xs"
                >
                  Take Survey & Earn Rs {survey.rewardRs} <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Survey Answering Modal */}
      {activeSurvey && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in">
          <div
            className={`w-full max-w-2xl my-8 p-6 sm:p-8 rounded-3xl border shadow-2xl space-y-6 ${
              isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800/60">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Reward: Rs {activeSurvey.rewardRs.toFixed(2)}
                </span>
                <h2 className="text-xl font-black text-slate-100 mt-1">{activeSurvey.title}</h2>
                <p className="text-xs text-slate-400 mt-0.5">{activeSurvey.description}</p>
              </div>

              <button
                onClick={() => setActiveSurvey(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmitSurvey} className="space-y-6">
              {activeSurvey.questions.map((q, idx) => (
                <div
                  key={q.id}
                  className={`p-4 rounded-2xl border ${
                    isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <p className="text-xs font-bold text-slate-200 mb-3 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px]">
                      {idx + 1}
                    </span>
                    <span>{q.question}</span>
                    {q.required && <span className="text-rose-400">*</span>}
                  </p>

                  {/* Multiple Choice Options */}
                  {q.type === 'multiple_choice' && q.options && (
                    <div className="space-y-2">
                      {q.options.map((opt) => (
                        <label
                          key={opt}
                          className={`flex items-center gap-3 p-2.5 rounded-xl border cursor-pointer text-xs transition-colors ${
                            answers[q.id] === opt
                              ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-semibold'
                              : isDark
                              ? 'border-slate-800/80 hover:bg-slate-900 text-slate-300'
                              : 'border-slate-200 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`q_${q.id}`}
                            value={opt}
                            checked={answers[q.id] === opt}
                            onChange={() => handleAnswerChange(q.id, opt)}
                            className="text-amber-500 focus:ring-amber-400"
                          />
                          <span>{opt}</span>
                        </label>
                      ))}
                    </div>
                  )}

                  {/* Yes / No Toggle */}
                  {q.type === 'yes_no' && (
                    <div className="grid grid-cols-2 gap-3">
                      {['Yes', 'No'].map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => handleAnswerChange(q.id, opt)}
                          className={`py-2.5 rounded-xl border text-xs font-bold transition-colors ${
                            answers[q.id] === opt
                              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm'
                              : isDark
                              ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Short Answer Text */}
                  {q.type === 'short_answer' && (
                    <textarea
                      rows={2}
                      required={q.required}
                      value={answers[q.id] || ''}
                      onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                      placeholder="Write your genuine feedback..."
                      className={`w-full p-3 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
                      }`}
                    />
                  )}
                </div>
              ))}

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveSurvey(null)}
                  className={`w-1/3 py-3 rounded-xl text-xs font-semibold border ${
                    isDark ? 'border-slate-800 text-slate-400 hover:bg-slate-800' : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Cancel
                </button>
                <button
                  id="submit-survey-btn"
                  type="submit"
                  disabled={submitting}
                  className="w-2/3 py-3 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity disabled:opacity-40 text-xs flex items-center justify-center gap-2"
                >
                  {submitting ? 'Submitting Responses...' : `Submit & Claim Rs ${activeSurvey.rewardRs.toFixed(2)}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
