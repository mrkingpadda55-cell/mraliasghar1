import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { ReferralSummary } from '../types';
import {
  Users,
  Copy,
  CheckCircle2,
  Share2,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';

interface ReferralsPageProps {
  onNavigate: (path: string) => void;
}

export const ReferralsPage: React.FC<ReferralsPageProps> = ({ onNavigate }) => {
  const { user, theme } = useAuth();
  const [data, setData] = useState<ReferralSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const fetchReferrals = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getReferrals();
      setData(res);
    } catch (err) {
      console.error('Error fetching referrals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferrals();
  }, []);

  const referralUrl = `${window.location.origin}/register?ref=${user?.referralCode}`;

  const copyToClipboard = (text: string, isUrl: boolean) => {
    navigator.clipboard.writeText(text);
    if (isUrl) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } else {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const isDark = theme === 'dark';

  return (
    <div id="referrals-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Earn Rs 10 per verified signup</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Referral Program
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
              Invite colleagues and friends to MR Aliasghar. Earn guaranteed Rs 10 for every legitimate registration completed through your link.
            </p>
          </div>

          <div className="px-5 py-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-center sm:text-right">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Referral Earnings</span>
            <span className="text-2xl font-black text-amber-400">
              Rs {(data?.totalReferralEarnings ?? 0).toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Share Box & Link Generator */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border shadow-sm space-y-6 ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Share2 className="w-4 h-4 text-amber-400" />
          <span>Your Invitation Credentials</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Unique Referral Code */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400">Referral Code</label>
            <div className="flex items-center gap-2">
              <div
                className={`flex-1 px-4 py-3 rounded-2xl font-mono text-sm font-black border tracking-wider select-all ${
                  isDark ? 'bg-slate-950 border-slate-800 text-amber-400' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              >
                {user?.referralCode}
              </div>
              <button
                id="copy-ref-code-btn"
                onClick={() => copyToClipboard(user?.referralCode || '', false)}
                className="px-4 py-3 rounded-2xl font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs flex items-center gap-1.5 transition-colors shrink-0"
              >
                {copiedCode ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copiedCode ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Direct Share Link */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400">Direct Invitation Link</label>
            <div className="flex items-center gap-2">
              <div
                className={`flex-1 px-4 py-3 rounded-2xl font-mono text-xs border truncate select-all ${
                  isDark ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-300 text-slate-800'
                }`}
              >
                {referralUrl}
              </div>
              <button
                id="copy-ref-link-btn"
                onClick={() => copyToClipboard(referralUrl, true)}
                className="px-4 py-3 rounded-2xl font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 text-xs flex items-center gap-1.5 transition-colors shrink-0"
              >
                {copiedLink ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copiedLink ? 'Copied' : 'Copy Link'}
              </button>
            </div>
          </div>
        </div>

        {/* Anti-Abuse notice */}
        <div className="p-3.5 rounded-2xl border border-slate-800 bg-slate-950/60 text-xs text-slate-400 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            Self-referrals, identical IPs, and duplicate device signups are automatically detected and blocked to ensure fair payouts.
          </span>
        </div>
      </div>

      {/* Referral Stats Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <span className="text-xs text-slate-400 block mb-1">Total Referrals</span>
          <div className="text-3xl font-black text-slate-100">
            {data?.totalReferrals ?? 0}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Members registered</span>
        </div>

        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <span className="text-xs text-slate-400 block mb-1">Bonus Per Friend</span>
          <div className="text-3xl font-black text-emerald-400">
            Rs {(data?.rewardPerReferral ?? 10).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Instant Rs credit</span>
        </div>

        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <span className="text-xs text-slate-400 block mb-1">Referral Rewards</span>
          <div className="text-3xl font-black text-amber-400">
            Rs {(data?.totalReferralEarnings ?? 0).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Credited to wallet</span>
        </div>
      </div>

      {/* Referred Users List */}
      <div
        className={`p-6 rounded-3xl border shadow-sm ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <h3 className="text-base font-bold text-slate-100 mb-4">Referred Members</h3>

        {loading ? (
          <div className="text-center py-8 text-xs text-slate-400">Loading referral list...</div>
        ) : !data?.referrals || data.referrals.length === 0 ? (
          <div className="text-center py-10 text-xs text-slate-500">
            No referred users yet. Share your referral link above to start earning!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5">Member Name</th>
                  <th className="py-2.5">Email</th>
                  <th className="py-2.5">Registered On</th>
                  <th className="py-2.5 text-right">Bonus Paid</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {(data.referrals || []).map((u: any) => (
                  <tr key={u.id}>
                    <td className="py-3 font-semibold text-slate-200">{u.referredUserName || u.name || 'Verified Member'}</td>
                    <td className="py-3 text-slate-400">{u.status || 'Active Member'}</td>
                    <td className="py-3 text-slate-400">{new Date(u.joinedAt || u.createdAt || Date.now()).toLocaleDateString()}</td>
                    <td className="py-3 text-right font-black text-emerald-400">+Rs {(u.rewardRs || 10).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
