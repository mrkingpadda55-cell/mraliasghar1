import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import {
  Sparkles,
  UploadCloud,
  CheckCircle2,
  Copy,
  Check,
  AlertCircle,
  Coins,
  Crown,
  Eye,
  FileImage,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import brandBg from '../assets/images/mraliasghar_brand_bg_1790026816381.jpg';
import sampleLogo from '../assets/images/mrking_logo_sample_1790026829949.jpg';

interface MrKingLogoPageProps {
  onNavigate: (path: string) => void;
}

export const MrKingLogoPage: React.FC<MrKingLogoPageProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [promptText, setPromptText] = useState<string>(
    'Luxury royal gold crown and lion crest vector emblem logo for brand name MR KING, high resolution VIP corporate branding, obsidian and metallic gold, 8k masterpiece'
  );
  const [copiedPrompt, setCopiedPrompt] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [isClaimed, setIsClaimed] = useState<boolean>(false);

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(promptText);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2500);
  };

  const handleFileProcess = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please upload a valid image file (PNG, JPG, JPEG, or WebP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('File size must be under 5MB.');
      return;
    }

    setErrorMsg(null);
    setSelectedFile(file);

    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleSubmitLogo = async () => {
    if (!imagePreview) {
      setErrorMsg('Please select or drag an image file to upload first.');
      return;
    }

    try {
      setSubmitting(true);
      setErrorMsg(null);

      const res = await apiClient.completeTask(
        'task_ai_mrking_logo',
        `Prompt: ${promptText.slice(0, 100)}`,
        imagePreview
      );

      setSuccessMsg(res.message || 'MR King Logo successfully uploaded! Rs 60.00 credited.');
      setIsClaimed(true);

      // Trigger Confetti
      confetti({
        particleCount: 120,
        spread: 90,
        origin: { y: 0.5 },
      });

      await refreshUser();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit logo. Please ensure you are logged in.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-4rem)] text-slate-100 overflow-hidden">
      {/* Visual MR ALIASGHAR Page Backdrop replacing plain background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <img
          src={brandBg}
          alt="MR Aliasghar Brand Background"
          className="w-full h-full object-cover opacity-35 filter brightness-75 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/85 to-slate-950" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-8 md:py-12 space-y-10">
        {/* Header Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-400/30 text-amber-300 text-xs font-bold tracking-wide uppercase shadow-lg shadow-amber-500/10">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>MR Aliasghar Official Brand Task</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white">
            Create AI Logo for{' '}
            <span className="bg-gradient-to-r from-amber-400 via-yellow-300 to-emerald-400 bg-clip-text text-transparent">
              MR King
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Generate an AI logo for <strong className="text-amber-400 font-semibold">MR King</strong> using any AI tool (ChatGPT, Bing Image Creator, Midjourney, etc.) and upload it directly to the website.
          </p>

          <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-amber-400/10 border border-amber-400/40 text-amber-300 shadow-md">
            <Coins className="w-5 h-5 text-amber-400 shrink-0" />
            <span className="text-sm font-bold">Guaranteed Reward:</span>
            <span className="text-xl font-extrabold text-amber-400 font-mono">Rs 60.00</span>
            <span className="text-xs text-slate-400">(Credited immediately to Available Balance)</span>
          </div>
        </div>

        {/* 3 Steps Guide Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur-md space-y-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center font-bold text-amber-400 text-xs font-mono">
              01
            </div>
            <h3 className="font-bold text-sm text-slate-100">Copy AI Prompt</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Use our optimized VIP prompt below or write your own creative prompt for "MR King".
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur-md space-y-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center font-bold text-emerald-400 text-xs font-mono">
              02
            </div>
            <h3 className="font-bold text-sm text-slate-100">Generate on Free AI</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Generate the logo on Bing Image Creator, ChatGPT DALL-E, Ideogram, or Gemini for free.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur-md space-y-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center font-bold text-cyan-400 text-xs font-mono">
              03
            </div>
            <h3 className="font-bold text-sm text-slate-100">Upload & Earn Rs 60</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Drag or upload the logo image file. Once uploaded, Rs 60.00 is instantly credited to your wallet!
            </p>
          </div>
        </div>

        {/* AI Prompt Helper Box */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-amber-400/20 backdrop-blur-md space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-bold text-slate-100">Ready-To-Use AI Image Prompt</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyPrompt}
                className="px-3.5 py-1.5 rounded-xl bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-300 transition-colors flex items-center gap-1.5 shadow-sm"
              >
                {copiedPrompt ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedPrompt ? 'Prompt Copied!' : 'Copy Prompt'}
              </button>

              <a
                href="https://www.bing.com/images/create"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800/80 text-slate-200 text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1"
              >
                <span>Bing AI Creator</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </div>
          </div>

          <textarea
            rows={2}
            value={promptText}
            onChange={(e) => setPromptText(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs leading-relaxed font-mono focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Upload Zone & Live Showcase Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Upload Card */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileImage className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-slate-100 text-sm">Upload AI 'MR King' Logo</h3>
              </div>
              <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded-full border border-emerald-400/20">
                1 Logo = Rs 60
              </span>
            </div>

            {/* Drag & Drop Area */}
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className={`p-8 border-2 border-dashed rounded-2xl text-center cursor-pointer transition-all ${
                isDragOver
                  ? 'border-amber-400 bg-amber-400/10'
                  : imagePreview
                  ? 'border-emerald-500/50 bg-emerald-500/5'
                  : 'border-slate-700 hover:border-amber-400/60 bg-slate-950/60 hover:bg-slate-950/90'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png, image/jpeg, image/jpg, image/webp"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileProcess(e.target.files[0]);
                  }
                }}
              />

              {imagePreview ? (
                <div className="space-y-3">
                  <div className="w-24 h-24 mx-auto rounded-2xl overflow-hidden border-2 border-emerald-400 shadow-lg shadow-emerald-500/20">
                    <img src={imagePreview} alt="Selected Logo Preview" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-emerald-400 flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Logo ready for upload
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {selectedFile ? `${selectedFile.name} (${(selectedFile.size / 1024).toFixed(1)} KB)` : 'Custom image'}
                    </p>
                  </div>
                  <p className="text-[11px] text-amber-400 underline">Click to choose another image</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
                    <UploadCloud className="w-7 h-7" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-200">
                      Drag & Drop your 'MR King' Logo here, or <span className="text-amber-400 underline">browse files</span>
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Supports PNG, JPG, JPEG, WebP (Max 5MB)
                    </p>
                  </div>
                </div>
              )}
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <div>
                  <p className="font-bold">{successMsg}</p>
                  <p className="text-[11px] text-emerald-400/80">
                    Rs 60.00 has been credited to your available balance.
                  </p>
                </div>
              </div>
            )}

            <button
              id="submit-mrking-logo-btn"
              type="button"
              disabled={!imagePreview || submitting || isClaimed}
              onClick={handleSubmitLogo}
              className="w-full py-3.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-emerald-400 hover:opacity-95 transition-opacity disabled:opacity-40 text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
            >
              {submitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Uploading & Verifying Logo...</span>
                </>
              ) : isClaimed ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-950" />
                  <span>Task Completed • Rs 60.00 Earned!</span>
                </>
              ) : (
                <>
                  <Coins className="w-4 h-4" />
                  <span>Upload Logo & Claim Rs 60.00</span>
                </>
              )}
            </button>
          </div>

          {/* Live Mockup Showcase Card */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-slate-100 text-sm">MR Aliasghar VIP Brand Mockup</h3>
              </div>
              <span className="text-[11px] text-slate-400">Live Stage Preview</span>
            </div>

            {/* VIP Brand Display Stage with custom background */}
            <div className="relative aspect-video rounded-xl overflow-hidden border border-amber-400/30 shadow-2xl flex items-center justify-center">
              <img
                src={brandBg}
                alt="MR Aliasghar Backdrop"
                className="absolute inset-0 w-full h-full object-cover filter brightness-90"
              />
              <div className="absolute inset-0 bg-slate-950/40" />

              {/* Centered Logo Preview */}
              <div className="relative z-10 p-6 text-center space-y-3">
                <div className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-2xl p-1 bg-gradient-to-tr from-amber-400 via-yellow-200 to-emerald-400 shadow-2xl shadow-amber-500/30 flex items-center justify-center">
                  <img
                    src={imagePreview || sampleLogo}
                    alt="MR King Logo Mockup"
                    className="w-full h-full object-cover rounded-xl bg-slate-950"
                  />
                </div>
                <div>
                  <h4 className="text-lg font-black tracking-wide text-white drop-shadow-md">
                    MR KING OF NAROWAL
                  </h4>
                  <p className="text-[11px] text-amber-300 font-semibold tracking-wider uppercase drop-shadow">
                    Official Brand Identity • MR Aliasghar Network
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-400 space-y-1">
              <p className="font-semibold text-slate-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Verified Task Policy
              </p>
              <p className="text-[11px]">
                Upon uploading a high quality AI-designed logo for "MR King", your submission is stored and verified. Rs 60 is credited immediately into your real wallet balance.
              </p>
            </div>
          </div>
        </div>

        {/* Community Approved Inspiration Gallery */}
        <div className="space-y-4 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-100">Approved MR King Community Showcase</h3>
              <p className="text-xs text-slate-400">Verified submissions created by platform members</p>
            </div>
            <button
              onClick={() => onNavigate('/tasks')}
              className="text-xs font-semibold text-amber-400 hover:underline flex items-center gap-1"
            >
              <span>View All Tasks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 rounded-xl bg-slate-900/90 border border-amber-400/20 space-y-2">
              <div className="aspect-square rounded-lg overflow-hidden bg-slate-950 border border-slate-800">
                <img src={sampleLogo} alt="Official MR King Vector" className="w-full h-full object-cover" />
              </div>
              <div className="text-[11px]">
                <p className="font-bold text-slate-200 truncate">Royal Lion Crest</p>
                <p className="text-emerald-400 font-mono font-semibold">+Rs 60.00 Awarded</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="aspect-square rounded-lg overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-2">
                <div className="w-full h-full rounded-md bg-gradient-to-tr from-amber-500/20 to-yellow-500/10 flex flex-col items-center justify-center text-center p-2">
                  <Crown className="w-8 h-8 text-amber-400 mb-1" />
                  <span className="font-extrabold text-amber-300 text-xs font-mono">MR KING</span>
                  <span className="text-[9px] text-slate-400">Crown Vector</span>
                </div>
              </div>
              <div className="text-[11px]">
                <p className="font-bold text-slate-200 truncate">Executive Crown</p>
                <p className="text-emerald-400 font-mono font-semibold">+Rs 60.00 Awarded</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="aspect-square rounded-lg overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-2">
                <div className="w-full h-full rounded-md bg-gradient-to-tr from-emerald-500/20 to-cyan-500/10 flex flex-col items-center justify-center text-center p-2">
                  <Sparkles className="w-8 h-8 text-emerald-400 mb-1" />
                  <span className="font-extrabold text-emerald-300 text-xs font-mono">NAROWAL</span>
                  <span className="text-[9px] text-slate-400">3D Mascot</span>
                </div>
              </div>
              <div className="text-[11px]">
                <p className="font-bold text-slate-200 truncate">Narowal Monarch</p>
                <p className="text-emerald-400 font-mono font-semibold">+Rs 60.00 Awarded</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="aspect-square rounded-lg overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-2">
                <div className="w-full h-full rounded-md bg-gradient-to-tr from-yellow-500/20 to-amber-600/10 flex flex-col items-center justify-center text-center p-2">
                  <Coins className="w-8 h-8 text-yellow-400 mb-1" />
                  <span className="font-extrabold text-yellow-300 text-xs font-mono">MR VIP</span>
                  <span className="text-[9px] text-slate-400">Gold Crest</span>
                </div>
              </div>
              <div className="text-[11px]">
                <p className="font-bold text-slate-200 truncate">Gold Shield Emblem</p>
                <p className="text-emerald-400 font-mono font-semibold">+Rs 60.00 Awarded</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
