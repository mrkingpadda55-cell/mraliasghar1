import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { PaymentMethod, Withdrawal } from '../types';
import confetti from 'canvas-confetti';
import {
  CreditCard,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  Info,
} from 'lucide-react';

interface WithdrawPageProps {
  onNavigate: (path: string) => void;
}

export const WithdrawPage: React.FC<WithdrawPageProps> = ({ onNavigate }) => {
  const { wallet, refreshUser, theme } = useAuth();
  const [method, setMethod] = useState<PaymentMethod>('JazzCash');
  const [amount, setAmount] = useState<string>('100');
  const [accountHolderName, setAccountHolderName] = useState<string>('');
  const [mobileNumber, setMobileNumber] = useState<string>('');
  const [binancePayId, setBinancePayId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const [settings, setSettings] = useState<{
    minWithdrawal: number;
    maxWithdrawal: number;
    withdrawalFeePercent: number;
    availableMethods: PaymentMethod[];
  }>({
    minWithdrawal: 100,
    maxWithdrawal: 50000,
    withdrawalFeePercent: 0,
    availableMethods: ['JazzCash', 'Easypaisa', 'Binance'],
  });

  const [userWithdrawals, setUserWithdrawals] = useState<Withdrawal[]>([]);

  useEffect(() => {
    async function loadData() {
      try {
        const res = await apiClient.getWallet();
        if (res.settings) {
          setSettings(res.settings);
        }
        setUserWithdrawals(res.withdrawals || []);
      } catch (err) {
        console.error('Failed to load wallet settings:', err);
      }
    }
    loadData();
  }, []);

  const numAmount = Number(amount) || 0;
  const fee = Math.round(((numAmount * (settings.withdrawalFeePercent || 0)) / 100) * 100) / 100;
  const netAmount = Math.max(0, numAmount - fee);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (numAmount < settings.minWithdrawal) {
      setErrorMsg(`Minimum withdrawal amount is Rs ${settings.minWithdrawal}.`);
      return;
    }

    if (numAmount > settings.maxWithdrawal) {
      setErrorMsg(`Maximum withdrawal amount is Rs ${settings.maxWithdrawal}.`);
      return;
    }

    if ((wallet?.availableBalance ?? 0) < numAmount) {
      setErrorMsg(`Insufficient available balance. You currently have Rs ${(wallet?.availableBalance ?? 0).toFixed(2)}.`);
      return;
    }

    // Specific validation
    if (method === 'JazzCash' || method === 'Easypaisa') {
      if (!accountHolderName.trim()) {
        setErrorMsg('Please enter account holder name / title.');
        return;
      }
      if (!mobileNumber.trim() || mobileNumber.trim().length < 10) {
        setErrorMsg('Please enter a valid 11-digit mobile account number.');
        return;
      }
    } else if (method === 'Binance') {
      if (!binancePayId.trim()) {
        setErrorMsg('Please enter your Binance Pay ID or address.');
        return;
      }
    }

    try {
      setLoading(true);
      const res = await apiClient.requestWithdrawal({
        amount: numAmount,
        paymentMethod: method,
        accountDetails: {
          accountHolderName: accountHolderName.trim(),
          mobileNumber: mobileNumber.trim(),
          binancePayId: binancePayId.trim(),
          notes: notes.trim(),
        },
      });

      setSuccessMsg(res.message);
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });

      await refreshUser();
      // Add to list
      setUserWithdrawals((prev) => [res.withdrawal, ...prev]);

      // Reset form
      setAmount(settings.minWithdrawal.toString());
      setAccountHolderName('');
      setMobileNumber('');
      setBinancePayId('');
      setNotes('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Withdrawal request failed.');
    } finally {
      setLoading(false);
    }
  };

  const isDark = theme === 'dark';

  return (
    <div id="withdraw-page" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-2">
              <CreditCard className="w-3.5 h-3.5" />
              <span>Pakistani Rupee Payout Desk</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Request Withdrawal
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Minimum withdrawal: <strong className="text-amber-400">Rs {settings.minWithdrawal}</strong> • Available Balance: <strong className="text-emerald-400">Rs {(wallet?.availableBalance ?? 0).toFixed(2)}</strong>
            </p>
          </div>

          <div className="px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-right">
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Your Balance</span>
            <span className="text-lg font-black text-amber-400">
              Rs {(wallet?.availableBalance ?? 0).toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Legitimacy Notice */}
      <div className="p-4 rounded-2xl border border-amber-500/20 bg-amber-500/5 text-xs text-slate-300 flex items-start gap-3">
        <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-slate-100">Payout Processing Policy:</p>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            To uphold full transparency, MR Aliasghar processes payouts via scheduled administrative disbursement. Withdrawals enter a <strong>“Pending”</strong> state until reviewed and dispatched to your provided JazzCash, Easypaisa, or Binance account.
          </p>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border shadow-xl ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Method Selection Tabs */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Select Payout Method
            </label>
            <div className="grid grid-cols-3 gap-3">
              {(settings.availableMethods || ['JazzCash', 'Easypaisa', 'Binance']).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMethod(m)}
                  className={`py-3 px-4 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center gap-1.5 ${
                    method === m
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                      : isDark
                      ? 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-extrabold text-sm">{m}</span>
                  <span className="text-[10px] opacity-80">
                    {m === 'Binance' ? 'Binance Pay ID' : 'Mobile Account'}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Amount in Pakistani Rupees (Rs)
              </label>
              <span className="text-xs text-slate-500">
                Min: Rs {settings.minWithdrawal} • Max: Rs {settings.maxWithdrawal}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-sm text-slate-400">
                Rs
              </span>
              <input
                id="withdraw-amount-input"
                type="number"
                min={settings.minWithdrawal}
                max={settings.maxWithdrawal}
                step="1"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="100"
                className={`w-full pl-12 pr-4 py-3 rounded-2xl text-base font-bold border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                  isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              />
            </div>

            {/* Quick Amount Chips */}
            <div className="flex items-center gap-2 mt-2">
              {[100, 250, 500, 1000, 2500].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(amt.toString())}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold border ${
                    amount === amt.toString()
                      ? 'bg-amber-500/20 border-amber-500 text-amber-400'
                      : isDark
                      ? 'border-slate-800 text-slate-400 hover:text-slate-200'
                      : 'border-slate-200 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Rs {amt}
                </button>
              ))}
            </div>
          </div>

          {/* Method Specific Fields */}
          {(method === 'JazzCash' || method === 'Easypaisa') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Account Holder Name / Title
                </label>
                <input
                  id="account-holder-name-input"
                  type="text"
                  required
                  value={accountHolderName}
                  onChange={(e) => setAccountHolderName(e.target.value)}
                  placeholder="e.g. Muhammad Ali"
                  className={`w-full px-4 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                    isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {method} Mobile Number
                </label>
                <input
                  id="mobile-number-input"
                  type="text"
                  required
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="0300 1234567"
                  className={`w-full px-4 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                    isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>
            </div>
          )}

          {method === 'Binance' && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Binance Pay ID or USDT (TRC20) Payout Identifier
              </label>
              <input
                id="binance-pay-id-input"
                type="text"
                required
                value={binancePayId}
                onChange={(e) => setBinancePayId(e.target.value)}
                placeholder="e.g. 192837465 or USDT TRC20 address"
                className={`w-full px-4 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                  isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Optional Note for Administrator
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Please disburse in evening batch"
              className={`w-full px-4 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          {/* Breakdown summary */}
          <div className="p-4 rounded-2xl border border-slate-800 bg-slate-950/60 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Requested Amount:</span>
              <span className="font-semibold text-slate-200">Rs {numAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Processing Fee ({settings.withdrawalFeePercent}%):</span>
              <span className="font-semibold text-slate-200">Rs {fee.toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t border-slate-800 flex justify-between font-bold text-slate-100 text-sm">
              <span>Net Payout:</span>
              <span className="text-emerald-400">Rs {netAmount.toFixed(2)}</span>
            </div>
          </div>

          <button
            id="submit-withdrawal-btn"
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-2xl font-black text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-lg shadow-amber-500/20 hover:opacity-95 transition-opacity disabled:opacity-40 text-sm flex items-center justify-center gap-2"
          >
            {loading ? 'Submitting Request...' : `Submit Withdrawal (Rs ${numAmount.toFixed(2)})`}
            {!loading && <ArrowRight className="w-4 h-4" />}
          </button>
        </form>
      </div>

      {/* Payout History in Withdraw Page */}
      {userWithdrawals.length > 0 && (
        <div
          className={`p-6 rounded-3xl border ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <h3 className="text-base font-bold text-slate-100 mb-3">Your Withdrawal Requests</h3>
          <div className="space-y-3">
            {userWithdrawals.map((w) => (
              <div
                key={w.id}
                className={`p-3.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 ${
                  isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-slate-200">{w.id}</span>
                    <span className="text-xs text-slate-400">via {w.paymentMethod}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {new Date(w.createdAt).toLocaleString()} • {w.adminNote || 'Awaiting processing'}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-extrabold text-slate-100">Rs {w.amount.toFixed(2)}</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      w.status === 'Paid'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : w.status === 'Pending'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {w.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
