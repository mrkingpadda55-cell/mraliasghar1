import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  HelpCircle,
  ShieldCheck,
  FileText,
  Lock,
  Mail,
  Phone,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface HelpPageProps {
  initialTab?: 'faq' | 'terms' | 'privacy';
  onNavigate: (path: string) => void;
}

export const HelpPage: React.FC<HelpPageProps> = ({ initialTab = 'faq', onNavigate }) => {
  const { theme } = useAuth();
  const [tab, setTab] = useState<'faq' | 'terms' | 'privacy'>(initialTab);
  const isDark = theme === 'dark';

  return (
    <div id="help-page" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Transparency & Support</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
          MR Aliasghar Help Center
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Everything you need to know about our Pakistani Rupee rewards, verification procedures, and policies.
        </p>

        {/* Tab switch */}
        <div className="flex items-center gap-2 mt-6 border-t border-slate-800/80 pt-4">
          <button
            onClick={() => setTab('faq')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === 'faq' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            FAQ
          </button>
          <button
            onClick={() => setTab('terms')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === 'terms' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Terms of Service
          </button>
          <button
            onClick={() => setTab('privacy')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === 'privacy' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Privacy Policy
          </button>
        </div>
      </div>

      {tab === 'faq' && (
        <div className="space-y-4">
          <div className={`p-6 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-sm font-bold text-slate-100 mb-2">How do rewards work on MR Aliasghar?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every reward is credited in Pakistani Rupees (Rs). When you complete a promotional task, take a consumer survey, or claim your 24-hour daily check-in, our server verifies the completion parameters and credits your account balance instantly.
            </p>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-sm font-bold text-slate-100 mb-2">How do I withdraw my funds?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Once your available balance reaches at least Rs 100, navigate to the <strong>Withdraw</strong> page. Select either <strong>JazzCash</strong>, <strong>Easypaisa</strong>, or <strong>Binance</strong>, provide your registered account title and mobile number, and submit your request.
            </p>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-sm font-bold text-slate-100 mb-2">Why does my withdrawal show "Pending"?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              To guarantee legitimate transactions and protect users from fraudulent automation, withdrawals are reviewed and dispatched in administrative disbursement batches. You will never see fake automated payment stamps.
            </p>
          </div>

          <div className={`p-6 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-sm font-bold text-slate-100 mb-2">Can I create multiple accounts?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              No. Multi-accounting, self-referrals, and fraudulent proxy use are strictly forbidden and will result in wallet forfeiture and account suspension.
            </p>
          </div>
        </div>
      )}

      {tab === 'terms' && (
        <div className={`p-6 sm:p-8 rounded-3xl border space-y-4 text-xs text-slate-300 leading-relaxed ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h2 className="text-lg font-bold text-slate-100">Terms of Service</h2>
          <p>
            Welcome to MR Aliasghar. By creating an account or accessing this rewards and survey platform, you agree to comply with these terms.
          </p>
          <h3 className="font-bold text-slate-200 pt-2">1. Legitimate Engagement</h3>
          <p>
            Users must complete surveys and promotional tasks honestly and independently. Scripting, botting, emulator exploitation, or falsifying responses will trigger automated account suspension.
          </p>
          <h3 className="font-bold text-slate-200 pt-2">2. Pakistani Rupee (Rs) Balance</h3>
          <p>
            All balances reflect verified credits held for legitimate platform engagement. The minimum threshold for withdrawal requests is Rs 100 unless modified by platform administration.
          </p>
          <h3 className="font-bold text-slate-200 pt-2">3. Disbursal Policies</h3>
          <p>
            Withdrawals are processed manually via JazzCash, Easypaisa, or Binance. Users are responsible for providing correct account titles and 11-digit phone numbers.
          </p>
        </div>
      )}

      {tab === 'privacy' && (
        <div className={`p-6 sm:p-8 rounded-3xl border space-y-4 text-xs text-slate-300 leading-relaxed ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <h2 className="text-lg font-bold text-slate-100">Privacy Policy</h2>
          <p>
            MR Aliasghar respects your personal privacy. We collect minimal information required to maintain your account and disburse payouts.
          </p>
          <h3 className="font-bold text-slate-200 pt-2">Information Collected</h3>
          <p>
            We collect your name, email address, optional contact phone number, and withdrawal account destination details. Passwords are cryptographically salted and hashed using bcrypt.
          </p>
          <h3 className="font-bold text-slate-200 pt-2">Data Protection</h3>
          <p>
            We do not sell personal data to unauthorized third parties. Survey responses are aggregated anonymously for consumer sentiment studies.
          </p>
        </div>
      )}

      {/* Support Box */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-950/40 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-slate-100">Still have questions?</h4>
          <p className="text-xs text-slate-400">Our customer team is here to assist you.</p>
        </div>
        <div className="flex items-center gap-4 text-xs font-semibold">
          <a
            href="mailto:support@mraliasghar.com"
            className="px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 transition-colors flex items-center gap-1.5"
          >
            <Mail className="w-3.5 h-3.5" /> Email Support
          </a>
        </div>
      </div>
    </div>
  );
};
