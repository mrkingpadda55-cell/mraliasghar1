import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { User, TaskItem, SurveyItem, Withdrawal, PlatformSettings } from '../types';
import {
  ShieldCheck,
  Users,
  CheckSquare,
  FileText,
  CreditCard,
  Settings,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Search,
  Plus,
  Trash2,
  Edit2,
  DollarSign,
  Ban,
  Lock,
  RefreshCw,
  X,
  ExternalLink,
} from 'lucide-react';

interface AdminPageProps {
  onNavigate: (path: string) => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onNavigate }) => {
  const { user, theme } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'tasks' | 'surveys' | 'withdrawals' | 'settings'>('overview');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [tasksList, setTasksList] = useState<TaskItem[]>([]);
  const [surveysList, setSurveysList] = useState<SurveyItem[]>([]);
  const [withdrawalsList, setWithdrawalsList] = useState<Withdrawal[]>([]);
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings | null>(null);

  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Search & Filter States
  const [userSearch, setUserSearch] = useState('');
  const [withdrawalFilter, setWithdrawalFilter] = useState('ALL');

  // Modals
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showSurveyModal, setShowSurveyModal] = useState(false);
  const [showBalanceModal, setShowBalanceModal] = useState<{ userId: string; userName: string } | null>(null);
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceReason, setBalanceReason] = useState('');

  // Task Form State
  const [taskForm, setTaskForm] = useState<any>({
    title: '',
    platform: 'YouTube',
    description: '',
    destinationUrl: 'https://',
    rewardRs: 5,
    minDwellSeconds: 15,
    requiresProof: false,
    proofPrompt: 'Enter handle / username:',
    dailyLimit: 100,
    status: 'active',
    isActive: true,
  });

  // Survey Form State
  const [surveyForm, setSurveyForm] = useState<{
    title: string;
    description: string;
    rewardRs: number;
    durationMinutes: number;
    maxParticipants: number;
    isActive: boolean;
    questions: any[];
  }>({
    title: '',
    description: '',
    rewardRs: 25,
    durationMinutes: 5,
    maxParticipants: 500,
    isActive: true,
    questions: [
      {
        id: 'q1',
        question: 'Which digital wallet do you use most frequently?',
        type: 'multiple_choice',
        options: ['JazzCash', 'Easypaisa', 'SadaPay', 'NayaPay'],
        required: true,
      },
    ],
  });

  const loadAdminData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [dashRes, usersRes, tasksRes, surveysRes, withRes, settRes] = await Promise.all([
        apiClient.getAdminDashboard(),
        apiClient.getAdminUsers(),
        apiClient.getAdminTasks(),
        apiClient.getAdminSurveys(),
        apiClient.getAdminWithdrawals(),
        apiClient.getAdminSettings(),
      ]);

      setStats(dashRes.stats);
      setUsersList(usersRes.users);
      setTasksList(tasksRes.tasks);
      setSurveysList(surveysRes.surveys);
      setWithdrawalsList(withRes.withdrawals);
      setPlatformSettings(settRes.settings);
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
      setError(err.message || 'Access denied or admin error.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  // Balance Adjustment
  const handleAdjustBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showBalanceModal) return;

    try {
      await apiClient.adminAdjustBalance({
        userId: showBalanceModal.userId,
        amount: Number(balanceAmount),
        reason: balanceReason,
      });
      setMessage('User balance updated successfully.');
      setShowBalanceModal(null);
      setBalanceAmount('');
      setBalanceReason('');
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Balance adjustment failed.');
    }
  };

  // User Ban / Unban
  const handleToggleBan = async (u: any) => {
    const nextStatus = u.status === 'banned' ? 'active' : 'banned';
    try {
      await apiClient.adminUpdateUserStatus(u.id, nextStatus);
      setMessage(`User status set to ${nextStatus}.`);
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Status update failed.');
    }
  };

  // Task Save
  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.adminCreateTask(taskForm);
      setMessage('New promotional task created.');
      setShowTaskModal(false);
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Task creation failed.');
    }
  };

  const handleDeleteTask = async (id: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
      await apiClient.adminDeleteTask(id);
      setMessage('Task deleted.');
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Delete failed.');
    }
  };

  // Survey Save
  const handleSaveSurvey = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiClient.adminCreateSurvey(surveyForm);
      setMessage('New survey created.');
      setShowSurveyModal(false);
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Survey creation failed.');
    }
  };

  const handleDeleteSurvey = async (id: string) => {
    if (!confirm('Are you sure you want to delete this survey?')) return;
    try {
      await apiClient.adminDeleteSurvey(id);
      setMessage('Survey deleted.');
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Delete failed.');
    }
  };

  // Withdrawal Status Update
  const handleUpdateWithdrawal = async (id: string, status: string, note?: string) => {
    try {
      await apiClient.adminUpdateWithdrawal(id, { status, adminNote: note || `Updated to ${status}` });
      setMessage(`Withdrawal ${id} marked as ${status}.`);
      await loadAdminData();
    } catch (err: any) {
      setError(err.message || 'Failed to update withdrawal.');
    }
  };

  // Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!platformSettings) return;
    try {
      await apiClient.adminUpdateSettings(platformSettings);
      setMessage('Platform settings saved successfully.');
    } catch (err: any) {
      setError(err.message || 'Settings update failed.');
    }
  };

  const isDark = theme === 'dark';

  return (
    <div id="admin-panel" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Header */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>MR Aliasghar Administrative Master Control</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Admin Backoffice
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Oversee user accounts, review withdrawal requests, configure surveys, and manage payout settings.
            </p>
          </div>

          <button
            onClick={loadAdminData}
            className={`p-2.5 rounded-xl border ${
              isDark ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-100' : 'bg-slate-100 border-slate-300 text-slate-600'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
          </button>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-1 border-t border-slate-800/80 pt-4">
          {[
            { id: 'overview', label: 'Overview', icon: TrendingUp },
            { id: 'users', label: 'Users', icon: Users },
            { id: 'tasks', label: 'Social Tasks', icon: CheckSquare },
            { id: 'surveys', label: 'Surveys', icon: FileText },
            { id: 'withdrawals', label: 'Withdrawals', icon: CreditCard },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
                  active
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : isDark
                    ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {message && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{message}</span>
          </div>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Total Registered Users</span>
              <div className="text-3xl font-black text-slate-100">{stats?.totalUsers ?? 0}</div>
              <span className="text-[11px] text-slate-500 mt-1 block">Active community accounts</span>
            </div>

            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Total Rewards Distributed</span>
              <div className="text-3xl font-black text-emerald-400">Rs {(stats?.totalRewardsDistributed ?? 0).toFixed(2)}</div>
              <span className="text-[11px] text-slate-500 mt-1 block">All-time credited Rs</span>
            </div>

            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Pending Withdrawals</span>
              <div className="text-3xl font-black text-amber-400">
                {stats?.pendingWithdrawalsCount ?? 0} (Rs {(stats?.pendingWithdrawalsAmount ?? 0).toFixed(2)})
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Awaiting admin review</span>
            </div>

            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Tasks Completed</span>
              <div className="text-2xl font-black text-slate-200">{stats?.totalTasksCompleted ?? 0}</div>
            </div>

            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Surveys Completed</span>
              <div className="text-2xl font-black text-slate-200">{stats?.totalSurveysCompleted ?? 0}</div>
            </div>

            <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
              <span className="text-xs text-slate-400 block mb-1">Total Disbursed (Paid)</span>
              <div className="text-2xl font-black text-slate-200">Rs {(stats?.totalWithdrawnPaid ?? 0).toFixed(2)}</div>
            </div>
          </div>
        </div>
      )}

      {/* 2. USERS TAB */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search name, email, ID..."
                className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                  isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
                }`}
              />
            </div>
            <span className="text-xs text-slate-400">Total Users: {usersList.length}</span>
          </div>

          <div className={`p-6 rounded-3xl border overflow-x-auto ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5">User</th>
                  <th className="py-2.5">User ID</th>
                  <th className="py-2.5">Phone</th>
                  <th className="py-2.5">Role</th>
                  <th className="py-2.5">Status</th>
                  <th className="py-2.5">Available Rs</th>
                  <th className="py-2.5">Total Earned</th>
                  <th className="py-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {usersList
                  .filter((u) => {
                    const q = userSearch.toLowerCase();
                    return (
                      u.name.toLowerCase().includes(q) ||
                      u.email.toLowerCase().includes(q) ||
                      u.id.toLowerCase().includes(q)
                    );
                  })
                  .map((u) => (
                    <tr key={u.id} className="hover:bg-slate-800/20">
                      <td className="py-3">
                        <span className="font-bold text-slate-200 block">{u.name}</span>
                        <span className="text-[11px] text-slate-500">{u.email}</span>
                      </td>
                      <td className="py-3 font-mono text-[11px] text-slate-400">{u.id}</td>
                      <td className="py-3 text-slate-400">{u.phone || '—'}</td>
                      <td className="py-3">
                        <span className="uppercase font-bold text-[10px] text-amber-400">{u.role}</span>
                      </td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            u.status === 'banned'
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-emerald-500/20 text-emerald-400'
                          }`}
                        >
                          {u.status}
                        </span>
                      </td>
                      <td className="py-3 font-bold text-slate-100">
                        Rs {(u.wallet?.availableBalance ?? 0).toFixed(2)}
                      </td>
                      <td className="py-3 text-emerald-400 font-semibold">
                        Rs {(u.wallet?.totalEarned ?? 0).toFixed(2)}
                      </td>
                      <td className="py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setShowBalanceModal({ userId: u.id, userName: u.name })}
                            title="Adjust Balance"
                            className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleToggleBan(u)}
                            title={u.status === 'banned' ? 'Unban User' : 'Ban User'}
                            className={`p-1.5 rounded-lg border ${
                              u.status === 'banned'
                                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                                : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                            }`}
                          >
                            <Ban className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. TASKS TAB */}
      {activeTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-100">Configured Promotional Tasks</h3>
            <button
              id="admin-add-task-btn"
              onClick={() => setShowTaskModal(true)}
              className="px-4 py-2 rounded-xl font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" /> Add Task
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tasksList.map((t) => (
              <div
                key={t.id}
                className={`p-5 rounded-2xl border flex flex-col justify-between ${
                  isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {t.platform}
                    </span>
                    <span className="font-extrabold text-xs text-emerald-400">+Rs {t.rewardRs.toFixed(2)}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100 mb-1">{t.title}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-2">{t.description}</p>
                  <p className="text-[10px] text-slate-500 truncate mb-4">{t.destinationUrl}</p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
                  <span className="text-[11px] text-slate-400">{t.completionsCount} completions</span>
                  <button
                    onClick={() => handleDeleteTask(t.id)}
                    className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. SURVEYS TAB */}
      {activeTab === 'surveys' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-100">Active Consumer Surveys</h3>
            <button
              id="admin-add-survey-btn"
              onClick={() => setShowSurveyModal(true)}
              className="px-4 py-2 rounded-xl font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 text-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" /> Create Survey
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {surveysList.map((s) => (
              <div
                key={s.id}
                className={`p-5 rounded-2xl border flex flex-col justify-between ${
                  isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {s.questions.length} Questions
                    </span>
                    <span className="font-extrabold text-xs text-emerald-400">+Rs {s.rewardRs.toFixed(2)}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100 mb-1">{s.title}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-4">{s.description}</p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
                  <span className="text-[11px] text-slate-400">
                    {s.completedCount} / {s.maxParticipants} slots
                  </span>
                  <button
                    onClick={() => handleDeleteSurvey(s.id)}
                    className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. WITHDRAWALS TAB */}
      {activeTab === 'withdrawals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h3 className="text-base font-bold text-slate-100">Disbursement Processing Desk</h3>

            <div className="flex items-center gap-1.5">
              {['ALL', 'Pending', 'Processing', 'Paid', 'Rejected'].map((status) => (
                <button
                  key={status}
                  onClick={() => setWithdrawalFilter(status)}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold border ${
                    withdrawalFilter === status
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                      : 'border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div className={`p-6 rounded-3xl border overflow-x-auto ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5">Request ID</th>
                  <th className="py-2.5">User</th>
                  <th className="py-2.5">Method</th>
                  <th className="py-2.5">Account Details</th>
                  <th className="py-2.5">Amount (Rs)</th>
                  <th className="py-2.5">Status</th>
                  <th className="py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {withdrawalsList
                  .filter((w) => withdrawalFilter === 'ALL' || w.status === withdrawalFilter)
                  .map((w) => (
                    <tr key={w.id} className="hover:bg-slate-800/20">
                      <td className="py-3 font-mono font-bold text-slate-200">{w.id}</td>
                      <td className="py-3">
                        <span className="font-semibold text-slate-200 block">{w.userName}</span>
                        <span className="text-[10px] text-slate-500">{w.userEmail}</span>
                      </td>
                      <td className="py-3 font-semibold text-amber-400">{w.paymentMethod}</td>
                      <td className="py-3 text-slate-300 max-w-xs">
                        {w.paymentMethod === 'Binance' ? (
                          <span>ID: {w.accountDetails?.binancePayId}</span>
                        ) : (
                          <span>
                            {w.accountDetails?.accountHolderName} ({w.accountDetails?.mobileNumber})
                          </span>
                        )}
                        {w.accountDetails?.notes && (
                          <span className="block text-[10px] text-slate-500 italic">Note: {w.accountDetails.notes}</span>
                        )}
                      </td>
                      <td className="py-3 font-black text-slate-100">Rs {w.amount.toFixed(2)}</td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            w.status === 'Paid'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : w.status === 'Pending'
                              ? 'bg-amber-500/20 text-amber-400'
                              : w.status === 'Processing'
                              ? 'bg-blue-500/20 text-blue-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {w.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {w.status === 'Pending' && (
                            <button
                              onClick={() => handleUpdateWithdrawal(w.id, 'Processing')}
                              className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[11px] font-semibold hover:bg-blue-500/20"
                            >
                              Process
                            </button>
                          )}
                          {(w.status === 'Pending' || w.status === 'Processing') && (
                            <>
                              <button
                                onClick={() => handleUpdateWithdrawal(w.id, 'Paid', 'Disbursed via official banking portal')}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold hover:bg-emerald-500/20"
                              >
                                Mark Paid
                              </button>
                              <button
                                onClick={() => {
                                  const reason = prompt('Rejection reason (balance will be refunded to user):', 'Incorrect account title / invalid mobile number');
                                  if (reason) handleUpdateWithdrawal(w.id, 'Rejected', reason);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 text-[11px] font-semibold hover:bg-rose-500/20"
                              >
                                Reject
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. SETTINGS TAB */}
      {activeTab === 'settings' && platformSettings && (
        <div
          className={`p-6 sm:p-8 rounded-3xl border shadow-sm max-w-2xl ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <h3 className="text-base font-bold text-slate-100 mb-6 flex items-center gap-2">
            <Settings className="w-4 h-4 text-amber-400" />
            <span>MR Aliasghar Platform Rules</span>
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Daily Reward Amount (Rs)</label>
                <input
                  type="number"
                  step="0.5"
                  value={platformSettings.dailyRewardAmount}
                  onChange={(e) =>
                    setPlatformSettings({ ...platformSettings, dailyRewardAmount: Number(e.target.value) })
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Referral Reward Amount (Rs)</label>
                <input
                  type="number"
                  step="1"
                  value={platformSettings.referralRewardAmount}
                  onChange={(e) =>
                    setPlatformSettings({ ...platformSettings, referralRewardAmount: Number(e.target.value) })
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Minimum Withdrawal (Rs)</label>
                <input
                  type="number"
                  value={platformSettings.minWithdrawal}
                  onChange={(e) =>
                    setPlatformSettings({ ...platformSettings, minWithdrawal: Number(e.target.value) })
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Maximum Withdrawal (Rs)</label>
                <input
                  type="number"
                  value={platformSettings.maxWithdrawal}
                  onChange={(e) =>
                    setPlatformSettings({ ...platformSettings, maxWithdrawal: Number(e.target.value) })
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Withdrawal Fee Percentage (%)</label>
              <input
                type="number"
                step="0.1"
                value={platformSettings.withdrawalFeePercent}
                onChange={(e) =>
                  setPlatformSettings({ ...platformSettings, withdrawalFeePercent: Number(e.target.value) })
                }
                className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
              />
            </div>

            <div className="pt-2">
              <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-800 bg-slate-950/60 cursor-pointer">
                <input
                  type="checkbox"
                  checked={platformSettings.maintenanceMode}
                  onChange={(e) =>
                    setPlatformSettings({ ...platformSettings, maintenanceMode: e.target.checked })
                  }
                  className="rounded text-amber-500 focus:ring-amber-400"
                />
                <div>
                  <span className="font-bold text-slate-200 block">Maintenance Mode</span>
                  <span className="text-[11px] text-slate-500">Temporarily freeze claims for routine maintenance</span>
                </div>
              </label>
            </div>

            <button
              type="submit"
              className="py-3 px-6 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 hover:opacity-95 text-xs mt-4"
            >
              Save Platform Configuration
            </button>
          </form>
        </div>
      )}

      {/* BALANCE ADJUST MODAL */}
      {showBalanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className={`w-full max-w-md p-6 rounded-3xl border shadow-2xl space-y-4 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-base font-bold text-slate-100">
              Adjust Balance: {showBalanceModal.userName}
            </h3>
            <p className="text-xs text-slate-400">
              Use positive values to add Rs (e.g. 50), or negative values to deduct (e.g. -20).
            </p>

            <form onSubmit={handleAdjustBalance} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Amount in Rs</label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={balanceAmount}
                  onChange={(e) => setBalanceAmount(e.target.value)}
                  placeholder="e.g. 50 or -25"
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Administrative Reason</label>
                <input
                  type="text"
                  required
                  value={balanceReason}
                  onChange={(e) => setBalanceReason(e.target.value)}
                  placeholder="e.g. Goodwill survey bonus"
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-100 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBalanceModal(null)}
                  className="w-1/2 py-2 rounded-xl text-xs font-semibold border border-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 rounded-xl font-bold text-slate-950 bg-amber-500 text-xs"
                >
                  Apply Change
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD TASK MODAL */}
      {showTaskModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className={`w-full max-w-lg p-6 rounded-3xl border shadow-2xl space-y-4 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-100">Create New Task</h3>
              <button onClick={() => setShowTaskModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTask} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  value={taskForm.title}
                  onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  placeholder="e.g. Follow official Instagram page"
                  className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Platform</label>
                  <select
                    value={taskForm.platform}
                    onChange={(e) => setTaskForm({ ...taskForm, platform: e.target.value as any })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  >
                    <option value="YouTube">YouTube</option>
                    <option value="TikTok">TikTok</option>
                    <option value="Facebook">Facebook</option>
                    <option value="Instagram">Instagram</option>
                    <option value="Website Visit">Website Visit</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Reward in Rs</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={taskForm.rewardRs}
                    onChange={(e) => setTaskForm({ ...taskForm, rewardRs: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Destination URL</label>
                <input
                  type="url"
                  required
                  value={taskForm.destinationUrl}
                  onChange={(e) => setTaskForm({ ...taskForm, destinationUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Task Instructions</label>
                <textarea
                  rows={2}
                  required
                  value={taskForm.description}
                  onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                  placeholder="Explain what the user must view or engage with..."
                  className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Dwell Time (Seconds)</label>
                  <input
                    type="number"
                    value={taskForm.minDwellSeconds}
                    onChange={(e) => setTaskForm({ ...taskForm, minDwellSeconds: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  />
                </div>
                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={taskForm.requiresProof}
                      onChange={(e) => setTaskForm({ ...taskForm, requiresProof: e.target.checked })}
                    />
                    <span className="text-slate-300">Require Username Proof</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 mt-2"
              >
                Create Task
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ADD SURVEY MODAL */}
      {showSurveyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className={`w-full max-w-lg p-6 rounded-3xl border shadow-2xl space-y-4 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-100">Create New Survey</h3>
              <button onClick={() => setShowSurveyModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSurvey} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Survey Title</label>
                <input
                  type="text"
                  required
                  value={surveyForm.title}
                  onChange={(e) => setSurveyForm({ ...surveyForm, title: e.target.value })}
                  placeholder="e.g. Telecom Network Satisfaction Survey"
                  className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  required
                  value={surveyForm.description}
                  onChange={(e) => setSurveyForm({ ...surveyForm, description: e.target.value })}
                  placeholder="Research description..."
                  className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Reward (Rs)</label>
                  <input
                    type="number"
                    step="1"
                    required
                    value={surveyForm.rewardRs}
                    onChange={(e) => setSurveyForm({ ...surveyForm, rewardRs: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Duration (Min)</label>
                  <input
                    type="number"
                    required
                    value={surveyForm.durationMinutes}
                    onChange={(e) => setSurveyForm({ ...surveyForm, durationMinutes: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Max Slots</label>
                  <input
                    type="number"
                    required
                    value={surveyForm.maxParticipants}
                    onChange={(e) => setSurveyForm({ ...surveyForm, maxParticipants: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl border border-slate-800 bg-slate-950 text-slate-100"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl border border-slate-800 bg-slate-950/60">
                <span className="font-semibold text-slate-300 block mb-1">Included Questions (Sample Set):</span>
                <p className="text-[11px] text-slate-400">
                  Multiple-choice consumer preferences and satisfaction rating questions will be attached automatically upon creation.
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 mt-2"
              >
                Publish Survey
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
