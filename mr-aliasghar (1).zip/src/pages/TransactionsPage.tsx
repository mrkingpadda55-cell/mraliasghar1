import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { Transaction } from '../types';
import { History, Filter, ArrowDownLeft, ArrowUpRight, Search, Download } from 'lucide-react';

interface TransactionsPageProps {
  onNavigate: (path: string) => void;
}

export const TransactionsPage: React.FC<TransactionsPageProps> = ({ onNavigate }) => {
  const { theme } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getTransactions();
      setTransactions(res.transactions);
    } catch (err) {
      console.error('Error fetching transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const filtered = transactions.filter((t) => {
    if (filterType !== 'ALL' && t.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.id.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.type.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const isDark = theme === 'dark';

  return (
    <div id="transactions-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-2">
              <History className="w-3.5 h-3.5" />
              <span>Immutable Rupee Ledger</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Transaction History
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Complete audit trail of all rewards, referrals, check-ins, and withdrawal disbursements.
            </p>
          </div>

          <div className="text-xs text-slate-400 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
            Total Records: <strong className="text-slate-100 font-mono">{filtered.length}</strong>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div
        className={`p-4 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-3 ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search description or ID..."
            className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
              isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Type Pills */}
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {[
            { id: 'ALL', label: 'All' },
            { id: 'task_reward', label: 'Tasks' },
            { id: 'survey_reward', label: 'Surveys' },
            { id: 'daily_reward', label: 'Daily' },
            { id: 'referral_reward', label: 'Referrals' },
            { id: 'withdrawal', label: 'Withdrawals' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setFilterType(item.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                filterType === item.id
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                  : isDark
                  ? 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Ledger Table */}
      <div
        className={`p-6 rounded-3xl border shadow-sm ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {loading ? (
          <div className="text-center py-12 text-slate-400 text-xs">Loading ledger entries...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            No transactions matching current filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800/80 text-slate-400 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-2">Type</th>
                  <th className="py-3 px-2">Transaction ID</th>
                  <th className="py-3 px-2">Description</th>
                  <th className="py-3 px-2">Date & Time</th>
                  <th className="py-3 px-2 text-right">Amount (Rs)</th>
                  <th className="py-3 px-2 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/20 transition-colors">
                    <td className="py-3.5 px-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                            t.amount >= 0
                              ? 'bg-emerald-500/10 text-emerald-400'
                              : 'bg-rose-500/10 text-rose-400'
                          }`}
                        >
                          {t.amount >= 0 ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                        </div>
                        <span className="capitalize font-semibold text-slate-300">
                          {t.type.replace('_', ' ')}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-2 font-mono text-[11px] text-slate-400">{t.id}</td>

                    <td className="py-3.5 px-2 text-slate-200 font-medium max-w-xs truncate">
                      {t.description}
                    </td>

                    <td className="py-3.5 px-2 text-slate-400">
                      {new Date(t.createdAt).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-2 text-right">
                      <span
                        className={`text-sm font-black ${
                          t.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {t.amount >= 0 ? `+Rs ${t.amount.toFixed(2)}` : `-Rs ${Math.abs(t.amount).toFixed(2)}`}
                      </span>
                    </td>

                    <td className="py-3.5 px-2 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          t.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : t.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
