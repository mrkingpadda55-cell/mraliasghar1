import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  ShieldCheck,
  CheckCircle2,
  FileText,
  Gift,
  CheckSquare,
  CreditCard,
  ArrowRight,
  Sparkles,
  HelpCircle,
  Mail,
  Phone,
  AlertTriangle,
  Lock,
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (path: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { user, theme } = useAuth();
  const isDark = theme === 'dark';

  return (
    <div id="landing-page" className="space-y-16 sm:space-y-24 py-8 sm:py-16">
      {/* Hero Section */}
      <section className="relative px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        {/* Decorative Ambient Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 sm:w-96 h-72 sm:h-96 bg-amber-500/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="relative inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs font-semibold mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Legitimate Rewards & Survey Portal in Pakistan</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-slate-100 max-w-4xl mx-auto leading-tight">
          <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-emerald-400 bg-clip-text text-transparent">
            MR Aliasghar
          </span>
        </h1>

        <p className="mt-4 text-xl sm:text-2xl text-slate-300 font-medium max-w-2xl mx-auto">
          “Complete legitimate tasks and surveys, earn rewards in Rs.”
        </p>

        <p className="mt-3 text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
          No fake points or fictitious claims. Every reward is denominated directly in Pakistani Rupees (Rs) and credited to your verified wallet after authentic task completion.
        </p>

        {/* Call to action buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          {user ? (
            <button
              id="hero-dashboard-btn"
              onClick={() => onNavigate('/dashboard')}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-lg shadow-amber-500/25 hover:opacity-95 transition-all flex items-center justify-center gap-2 text-base"
            >
              Go to Dashboard <ArrowRight className="w-5 h-5" />
            </button>
          ) : (
            <>
              <button
                id="hero-register-btn"
                onClick={() => onNavigate('/register')}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-lg shadow-amber-500/25 hover:scale-102 transition-all flex items-center justify-center gap-2 text-base"
              >
                Register Free Account <ArrowRight className="w-5 h-5" />
              </button>
              <button
                id="hero-login-btn"
                onClick={() => onNavigate('/login')}
                className={`w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold border transition-all text-base ${
                  isDark
                    ? 'border-slate-800 bg-slate-900/80 text-slate-200 hover:bg-slate-800 hover:text-white'
                    : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-100'
                }`}
              >
                Sign In
              </button>
            </>
          )}
        </div>

        {/* Verification Transparency Notice */}
        <div className="mt-8 max-w-xl mx-auto p-3 rounded-xl border border-amber-500/20 bg-amber-500/5 text-xs text-slate-300 flex items-center gap-2 text-left">
          <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
          <span>
            <strong>Authenticity First:</strong> Rewards are credited only when verification criteria (time dwell, survey completion, proof verification) are met. No simulated bots or fake payouts.
          </span>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
            How It Works
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            A transparent 3-step pathway to earning genuine Rs rewards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div
            className={`p-6 rounded-2xl border transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/40' : 'bg-white border-slate-200 shadow-sm'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xl mb-4 border border-amber-500/30">
              1
            </div>
            <h3 className="text-lg font-bold text-slate-100 mb-2">Create Your Account</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Register with your name, email, and optional phone number. Your secure Rs wallet is created immediately on the server.
            </p>
          </div>

          <div
            className={`p-6 rounded-2xl border transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-emerald-500/40' : 'bg-white border-slate-200 shadow-sm'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xl mb-4 border border-emerald-500/30">
              2
            </div>
            <h3 className="text-lg font-bold text-slate-100 mb-2">Complete Surveys & Tasks</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Take legitimate market surveys and complete verified promotional tasks. Claim your daily check-in reward every 24 hours.
            </p>
          </div>

          <div
            className={`p-6 rounded-2xl border transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/40' : 'bg-white border-slate-200 shadow-sm'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xl mb-4 border border-amber-500/30">
              3
            </div>
            <h3 className="text-lg font-bold text-slate-100 mb-2">Withdraw in Rs</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Reach the minimum Rs 100 threshold and submit your payout request to JazzCash, Easypaisa, or Binance for administrator processing.
            </p>
          </div>
        </div>
      </section>

      {/* Feature Grids: Surveys, Daily Rewards, Tasks */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Surveys Showcase */}
        <div
          className={`p-8 rounded-3xl border ${
            isDark ? 'bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-3 max-w-xl">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                <FileText className="w-3.5 h-3.5" /> Real Market Research
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-100">
                High-Value Consumer Surveys
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Provide honest opinions on Pakistani retail, digital wallets, telecom networks, and fintech services. Earn between <strong className="text-emerald-400">Rs 20 to Rs 50</strong> per verified survey submission.
              </p>
            </div>
            <button
              onClick={() => onNavigate(user ? '/surveys' : '/login')}
              className="px-6 py-3 rounded-xl font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors shrink-0 flex items-center gap-2 text-sm"
            >
              Browse Surveys <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Daily Rewards & Social Tasks in 2 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Daily Reward Box */}
          <div
            className={`p-6 sm:p-8 rounded-3xl border flex flex-col justify-between ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Gift className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-slate-100">24-Hour Daily Reward</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Log in every day and claim your guaranteed daily allowance of <span className="text-amber-400 font-bold">Rs 2.00</span>. Timers and claims are verified server-side with strict 24-hour integrity.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">Cooldown: 24 Hours</span>
              <button
                onClick={() => onNavigate(user ? '/daily-reward' : '/login')}
                className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                Claim Reward <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Social Tasks Box */}
          <div
            className={`p-6 sm:p-8 rounded-3xl border flex flex-col justify-between ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                <CheckSquare className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-slate-100">Verified Social & Web Tasks</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Visit official channels across YouTube, TikTok, Facebook, and Instagram. Each task features genuine verification parameters and immediate Rs rewards upon legitimate completion.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">Reward: Rs 2 - Rs 15</span>
              <button
                onClick={() => onNavigate(user ? '/tasks' : '/login')}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
              >
                View Tasks <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Withdrawals Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`p-8 sm:p-12 rounded-3xl border text-center relative overflow-hidden ${
            isDark ? 'bg-slate-900/70 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="max-w-2xl mx-auto space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-bold border border-amber-500/30">
              <CreditCard className="w-3.5 h-3.5" /> Transparent Payouts
            </div>
            <h3 className="text-2xl sm:text-4xl font-extrabold text-slate-100">
              Withdraw Directly in Pakistani Rupees
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              We support standard local withdrawal channels with a low minimum threshold of <span className="font-bold text-emerald-400">Rs 100</span>.
            </p>

            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/60">
                <span className="text-xs font-bold text-rose-400">JazzCash</span>
                <p className="text-[11px] text-slate-400 mt-1">Direct to JazzCash account title and 11-digit mobile number.</p>
              </div>
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/60">
                <span className="text-xs font-bold text-emerald-400">Easypaisa</span>
                <p className="text-[11px] text-slate-400 mt-1">Direct to Easypaisa account title and mobile wallet number.</p>
              </div>
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950/60">
                <span className="text-xs font-bold text-amber-400">Binance</span>
                <p className="text-[11px] text-slate-400 mt-1">Convenient crypto payout identifier via Binance Pay ID.</p>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 pt-2">
              Note: Withdrawals are submitted securely to our administrative queue and processed manually within official verification windows.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
            Frequently Asked Questions
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Straightforward answers about our rewards policies.
          </p>
        </div>

        <div className="space-y-4">
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/40">
            <h4 className="text-sm font-bold text-slate-100 mb-1">Are earnings in points or real Rupees?</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              All rewards on <strong>MR Aliasghar</strong> are 100% in Pakistani Rupees (Rs). We never use points, coins, or confusing virtual conversion ratios.
            </p>
          </div>

          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/40">
            <h4 className="text-sm font-bold text-slate-100 mb-1">What is the minimum withdrawal limit?</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              The minimum payout request is <strong>Rs 100</strong>. Once your available balance reaches Rs 100, you can request payment to your JazzCash, Easypaisa, or Binance account.
            </p>
          </div>

          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/40">
            <h4 className="text-sm font-bold text-slate-100 mb-1">How are social tasks verified?</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Promotional tasks use time-dwell verification (requiring authentic viewing time before reward unlock) and handle/proof confirmation. We do not make false claims of engagement without verification.
            </p>
          </div>

          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/40">
            <h4 className="text-sm font-bold text-slate-100 mb-1">How does the referral program work?</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Share your personal link (`/register?ref=CODE`). When a verified member registers using your code, your wallet is credited with Rs 10. Self-referrals and duplicate accounts are strictly prevented.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center pb-8">
        <div className="p-8 rounded-2xl border border-slate-800 bg-slate-900/30 space-y-4">
          <h3 className="text-xl font-bold text-slate-100">Need Help or Have Inquiries?</h3>
          <p className="text-xs text-slate-400 max-w-lg mx-auto">
            Our support desk is available to assist you with reward verification, survey inquiries, and withdrawal processing.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 pt-2 text-xs font-semibold text-slate-300">
            <span className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-amber-400" /> support@mraliasghar.com
            </span>
            <span className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400" /> +92 300 1234567
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
