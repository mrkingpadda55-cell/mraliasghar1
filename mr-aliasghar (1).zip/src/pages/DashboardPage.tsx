import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import {
  Wallet,
  TrendingUp,
  Clock,
  CheckCircle2,
  Gift,
  FileText,
  CheckSquare,
  CreditCard,
  History,
  User,
  ArrowRight,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { Transaction } from '../types';

interface DashboardPageProps {
  onNavigate: (path: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { user, wallet, refreshUser, theme } = useAuth();
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<{
    todayEarnings: number;
    totalEarnings: number;
    pendingWithdrawal: number;
    totalWithdrawn: number;
    completedTasksCount: number;
    completedSurveysCount: number;
    recentTransactions: Transaction[];
  } | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getDashboardSummary();
      setSummary(res);
      await refreshUser();
    } catch (err) {
      console.error('Error fetching dashboard summary:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const isDark = theme === 'dark';

  return (
    <div id="dashboard-page" className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Welcome Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border relative overflow-hidden shadow-sm ${
          isDark
            ? 'bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-slate-800'
            : 'bg-gradient-to-r from-amber-50 via-white to-emerald-50 border-slate-200'
        }`}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>MR Aliasghar Verified Portal</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-slate-100">
              Welcome, <span className="bg-gradient-to-r from-amber-400 to-emerald-400 bg-clip-text text-transparent">{user?.name}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Member ID: <span className="font-mono text-slate-300 font-semibold">{user?.id}</span> • Referral Code: <span className="font-mono text-amber-400 font-bold">{user?.referralCode}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadData}
              title="Refresh Balance & Metrics"
              className={`p-2.5 rounded-xl border transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800' : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
            <button
              id="dash-quick-withdraw-btn"
              onClick={() => onNavigate('/withdraw')}
              className="px-5 py-2.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity flex items-center gap-2 text-xs sm:text-sm"
            >
              <CreditCard className="w-4 h-4" /> Withdraw Rs
            </button>
          </div>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Today's Earnings */}
        <div
          id="metric-today-earnings"
          className={`p-5 rounded-2xl border transition-all ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Today's Earnings</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-400">
            Rs {(summary?.todayEarnings ?? 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Credited since 00:00 PST</p>
        </div>

        {/* Total Earnings */}
        <div
          id="metric-total-earnings"
          className={`p-5 rounded-2xl border transition-all ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Total Earnings</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-400">
            Rs {(wallet?.totalEarned ?? 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Lifetime verified rewards</p>
        </div>

        {/* Available Balance */}
        <div
          id="metric-available-balance"
          className={`p-5 rounded-2xl border transition-all ring-1 ring-amber-500/20 ${
            isDark ? 'bg-slate-900/80 border-amber-500/30' : 'bg-amber-50/50 border-amber-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-amber-400">Available Balance</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-slate-100">
            Rs {(wallet?.availableBalance ?? 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Ready for withdrawal (Min Rs 100)</p>
        </div>

        {/* Pending Withdrawal */}
        <div
          id="metric-pending-withdrawal"
          className={`p-5 rounded-2xl border transition-all ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Pending Withdrawal</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-blue-400">
            Rs {(wallet?.pendingWithdrawal ?? 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Under admin processing queue</p>
        </div>
      </div>

      {/* Main 6 Action Buttons as Requested */}
      <div>
        <h2 className="text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
          <span>Main Controls</span>
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            id="dash-btn-earn-now"
            onClick={() => onNavigate('/tasks')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/50 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-amber-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <CheckSquare className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-100">Earn Now</span>
            <span className="text-[10px] text-slate-500">Social Tasks</span>
          </button>

          <button
            id="dash-btn-surveys"
            onClick={() => onNavigate('/surveys')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-emerald-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-100">Surveys</span>
            <span className="text-[10px] text-slate-500">Rs 20 - Rs 50</span>
          </button>

          <button
            id="dash-btn-daily-reward"
            onClick={() => onNavigate('/daily-reward')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/50 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-amber-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Gift className="w-5 h-5 animate-pulse" />
            </div>
            <span className="text-xs font-bold text-slate-100">Daily Reward</span>
            <span className="text-[10px] text-amber-400 font-semibold">Claim Rs 2.00</span>
          </button>

          <button
            id="dash-btn-withdraw"
            onClick={() => onNavigate('/withdraw')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-emerald-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <CreditCard className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-100">Withdraw</span>
            <span className="text-[10px] text-slate-500">JazzCash / Easy</span>
          </button>

          <button
            id="dash-btn-transactions"
            onClick={() => onNavigate('/transactions')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-slate-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <History className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-100">History</span>
            <span className="text-[10px] text-slate-500">Ledger</span>
          </button>

          <button
            id="dash-btn-profile"
            onClick={() => onNavigate('/profile')}
            className={`p-4 rounded-2xl border flex flex-col items-center justify-center text-center group transition-all ${
              isDark ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900' : 'bg-white border-slate-200 hover:border-slate-400 shadow-sm'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <User className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-100">Profile</span>
            <span className="text-[10px] text-slate-500">Security</span>
          </button>
        </div>
      </div>

      {/* Two Column Layout: Activity Feed & Referral Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions Feed */}
        <div
          className={`lg:col-span-2 p-6 rounded-3xl border ${
            isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-100">Recent Transactions</h3>
              <p className="text-xs text-slate-400">Authentic balance ledger entries</p>
            </div>
            <button
              onClick={() => onNavigate('/transactions')}
              className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              View All <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {summary?.recentTransactions && summary.recentTransactions.length > 0 ? (
              summary.recentTransactions.map((t) => (
                <div
                  key={t.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition-colors ${
                    isDark ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-slate-200">{t.description}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                      <span>•</span>
                      <span className="capitalize">{t.type}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span
                      className={`text-sm font-extrabold ${
                        t.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {t.amount >= 0 ? `+Rs ${t.amount.toFixed(2)}` : `-Rs ${Math.abs(t.amount).toFixed(2)}`}
                    </span>
                    <span className="block text-[10px] text-slate-500 uppercase">{t.status}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-xs text-slate-500">
                No transactions yet. Complete a task or claim your daily reward!
              </div>
            )}
          </div>
        </div>

        {/* Quick Referral Box */}
        <div
          className={`p-6 rounded-3xl border flex flex-col justify-between ${
            isDark ? 'bg-gradient-to-b from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}
        >
          <div className="space-y-3">
            <span className="inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
              Referral Bonus
            </span>
            <h3 className="text-lg font-bold text-slate-100">Invite Friends & Earn</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Earn <span className="text-amber-400 font-bold">Rs 10.00</span> for every verified user who joins through your unique link.
            </p>

            <div className={`p-3 rounded-xl border font-mono text-xs text-slate-300 break-all select-all ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-300'}`}>
              /register?ref={user?.referralCode}
            </div>
          </div>

          <button
            onClick={() => onNavigate('/referrals')}
            className="mt-6 w-full py-2.5 rounded-xl font-bold bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            Manage Referrals <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
