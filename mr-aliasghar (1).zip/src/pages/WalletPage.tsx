import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { Wallet, Transaction, Withdrawal } from '../types';
import {
  CreditCard,
  TrendingUp,
  Clock,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  History,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';

interface WalletPageProps {
  onNavigate: (path: string) => void;
}

export const WalletPage: React.FC<WalletPageProps> = ({ onNavigate }) => {
  const { wallet, refreshUser, theme } = useAuth();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    wallet: Wallet;
    settings: any;
    transactions: Transaction[];
    withdrawals: Withdrawal[];
  } | null>(null);

  const fetchWallet = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getWallet();
      setData(res);
      await refreshUser();
    } catch (err) {
      console.error('Error fetching wallet:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWallet();
  }, []);

  const isDark = theme === 'dark';

  return (
    <div id="wallet-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Pakistani Rupee Ledger</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Rs Digital Wallet
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
              Server-authoritative wallet. Balances cannot be modified locally and are verified strictly against completed surveys, tasks, and approved withdrawals.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchWallet}
              className={`p-2.5 rounded-xl border ${
                isDark ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-100' : 'bg-slate-100 border-slate-300 text-slate-600'
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
            <button
              id="wallet-request-withdraw-btn"
              onClick={() => onNavigate('/withdraw')}
              className="px-6 py-2.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity flex items-center gap-2 text-xs sm:text-sm"
            >
              <CreditCard className="w-4 h-4" /> Withdraw Funds
            </button>
          </div>
        </div>
      </div>

      {/* 4 Wallet Financial Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl border border-amber-500/30 bg-amber-500/5">
          <span className="text-xs font-semibold text-amber-400 block mb-1">Available Balance</span>
          <div className="text-3xl font-black text-slate-100">
            Rs {(wallet?.availableBalance ?? 0).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Eligible for instant withdrawal</span>
        </div>

        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <span className="text-xs font-semibold text-slate-400 block mb-1">Pending Withdrawal</span>
          <div className="text-2xl font-black text-blue-400">
            Rs {(wallet?.pendingWithdrawal ?? 0).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Awaiting admin payout review</span>
        </div>

        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <span className="text-xs font-semibold text-slate-400 block mb-1">Total Earned</span>
          <div className="text-2xl font-black text-emerald-400">
            Rs {(wallet?.totalEarned ?? 0).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">All-time credited rewards</span>
        </div>

        <div className={`p-5 rounded-2xl border ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
          <span className="text-xs font-semibold text-slate-400 block mb-1">Total Withdrawn</span>
          <div className="text-2xl font-black text-slate-300">
            Rs {(wallet?.totalWithdrawn ?? 0).toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Successfully disbursed</span>
        </div>
      </div>

      {/* Recent Withdrawals Tracker */}
      <div
        className={`p-6 rounded-3xl border ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-100">Withdrawal History</h3>
            <p className="text-xs text-slate-400">Track verification and processing of your payout requests</p>
          </div>
          <button
            onClick={() => onNavigate('/withdraw')}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
          >
            New Request <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {data?.withdrawals && data.withdrawals.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-800/60 text-slate-400 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-2.5">Request ID</th>
                  <th className="py-2.5">Method</th>
                  <th className="py-2.5">Amount</th>
                  <th className="py-2.5">Status</th>
                  <th className="py-2.5">Date</th>
                  <th className="py-2.5">Admin Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {data.withdrawals.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-800/20">
                    <td className="py-3 font-mono font-bold text-slate-200">{w.id}</td>
                    <td className="py-3">
                      <span className="font-semibold text-slate-300">{w.paymentMethod}</span>
                    </td>
                    <td className="py-3 font-bold text-slate-100">Rs {w.amount.toFixed(2)}</td>
                    <td className="py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          w.status === 'Paid'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : w.status === 'Pending'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : w.status === 'Processing'
                            ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {w.status}
                      </span>
                    </td>
                    <td className="py-3 text-slate-400">{new Date(w.createdAt).toLocaleDateString()}</td>
                    <td className="py-3 text-slate-400 max-w-xs truncate">{w.adminNote || 'Under review'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-xs text-slate-500">
            No withdrawal requests yet. Minimum withdrawal threshold is Rs 100.
          </div>
        )}
      </div>

      {/* Transaction Ledger */}
      <div
        className={`p-6 rounded-3xl border ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-100">Transaction History</h3>
            <p className="text-xs text-slate-400">Complete immutable record of all Rs credits and debits</p>
          </div>
          <button
            onClick={() => onNavigate('/transactions')}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
          >
            Full Ledger <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-3">
          {data?.transactions && data.transactions.length > 0 ? (
            data.transactions.slice(0, 8).map((t) => (
              <div
                key={t.id}
                className={`p-3 rounded-xl border flex items-center justify-between ${
                  isDark ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <p className="text-xs font-bold text-slate-200">{t.description}</p>
                  <p className="text-[10px] text-slate-400">
                    {new Date(t.createdAt).toLocaleString()} • ID: {t.id}
                  </p>
                </div>
                <div className="text-right">
                  <span
                    className={`text-sm font-extrabold ${
                      t.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {t.amount >= 0 ? `+Rs ${t.amount.toFixed(2)}` : `-Rs ${Math.abs(t.amount).toFixed(2)}`}
                  </span>
                  <span className="block text-[10px] text-slate-500 uppercase">{t.status}</span>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-xs text-slate-500">
              No transactions recorded yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
