import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { apiClient } from '../api/client';
import { TaskItem } from '../types';
import confetti from 'canvas-confetti';
import {
  CheckSquare,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle,
  Youtube,
  Globe,
  Share2,
  Sparkles,
  Filter,
  Crown,
  ArrowRight,
  UploadCloud,
} from 'lucide-react';

interface TasksPageProps {
  onNavigate: (path: string) => void;
}

export const TasksPage: React.FC<TasksPageProps> = ({ onNavigate }) => {
  const { refreshUser, theme } = useAuth();
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');

  // Active Task Modal State
  const [activeTask, setActiveTask] = useState<TaskItem | null>(null);
  const [timerRemaining, setTimerRemaining] = useState<number>(0);
  const [timerCompleted, setTimerCompleted] = useState<boolean>(false);
  const [proofText, setProofText] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const res = await apiClient.getTasks();
      setTasks(res.tasks);
    } catch (err) {
      console.error('Error fetching tasks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  // Timer countdown hook for open task verification
  useEffect(() => {
    let interval: any = null;
    if (activeTask && timerRemaining > 0) {
      interval = setInterval(() => {
        setTimerRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setTimerCompleted(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeTask, timerRemaining]);

  const handleOpenTask = (task: TaskItem) => {
    if (task.id === 'task_ai_mrking_logo' || task.verificationMethod === 'image_upload' || task.platform === 'AI Design') {
      onNavigate('/mrking-logo');
      return;
    }

    setActiveTask(task);
    setTimerRemaining(task.minDwellSeconds || 15);
    setTimerCompleted(false);
    setProofText('');
    setErrorMsg(null);
    setSuccessMsg(null);

    // Open target destination URL in new tab
    window.open(task.destinationUrl, '_blank', 'noopener,noreferrer');
  };

  const handleClaimReward = async () => {
    if (!activeTask) return;
    if (!timerCompleted) {
      setErrorMsg(`Please engage with the task for ${timerRemaining} more seconds.`);
      return;
    }
    if (activeTask.requiresProof && (!proofText || proofText.trim().length < 2)) {
      setErrorMsg(activeTask.proofPrompt || 'Please enter proof/handle before claiming.');
      return;
    }

    try {
      setSubmitting(true);
      setErrorMsg(null);
      const res = await apiClient.completeTask(activeTask.id, proofText);
      setSuccessMsg(res.message);

      // Trigger Confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      await refreshUser();
      await fetchTasks();

      setTimeout(() => {
        setActiveTask(null);
      }, 2000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Task verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'AI Design':
        return <Crown className="w-5 h-5 text-amber-400" />;
      case 'YouTube':
        return <Youtube className="w-5 h-5 text-rose-500" />;
      case 'TikTok':
      case 'Instagram':
      case 'Facebook':
        return <Share2 className="w-5 h-5 text-amber-400" />;
      default:
        return <Globe className="w-5 h-5 text-emerald-400" />;
    }
  };

  const filteredTasks = tasks.filter((t) => {
    if (selectedFilter === 'ALL') return true;
    return t.platform === selectedFilter;
  });

  const isDark = theme === 'dark';

  return (
    <div id="tasks-page" className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header Banner */}
      <div
        className={`p-6 sm:p-8 rounded-3xl border ${
          isDark ? 'bg-gradient-to-r from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-2">
              <CheckSquare className="w-3.5 h-3.5" />
              <span>Verified Promotional & Social Tasks</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-100">
              Earn Rewards in Rs
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
              Complete legitimate promotional visits and official channel tasks. Rewards are credited to your available balance upon completed verification.
            </p>
          </div>

          {/* Quick Platform Filter */}
          <div className="flex flex-wrap items-center gap-1.5">
            {['ALL', 'AI Design', 'YouTube', 'TikTok', 'Facebook', 'Instagram', 'Website Visit'].map((f) => (
              <button
                key={f}
                onClick={() => setSelectedFilter(f)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  selectedFilter === f
                    ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                    : isDark
                    ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                    : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Featured High-Reward Task Spotlight */}
      <div className="relative overflow-hidden p-6 rounded-3xl border border-amber-400/30 bg-gradient-to-r from-amber-500/10 via-slate-900/90 to-emerald-500/10 backdrop-blur-md shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold uppercase tracking-wider border border-amber-400/30">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>Highest Reward Task • Rs 60.00</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Create AI Logo for 'MR King' & Upload
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Generate an AI logo for <strong className="text-amber-400">MR King</strong> using Bing AI, ChatGPT, or Midjourney and upload it to the website. Get Rs 60 credited directly to your wallet!
          </p>
        </div>

        <button
          id="spotlight-open-mrking-btn"
          onClick={() => onNavigate('/mrking-logo')}
          className="shrink-0 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-amber-500/20 hover:scale-102 transition-transform"
        >
          <UploadCloud className="w-4 h-4 text-slate-950" />
          <span>Launch AI Logo Studio</span>
          <ArrowRight className="w-4 h-4 text-slate-950" />
        </button>
      </div>

      {/* Task Grid */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">
          Loading available promotional tasks...
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="text-center py-16 p-8 rounded-3xl border border-slate-800 bg-slate-900/30">
          <p className="text-sm font-semibold text-slate-300">No active tasks in this category.</p>
          <p className="text-xs text-slate-500 mt-1">Check back later or explore our Surveys page for high rewards.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-5 rounded-2xl border flex flex-col justify-between transition-all ${
                task.isCompletedByUser
                  ? isDark
                    ? 'bg-slate-950/40 border-slate-800/50 opacity-70'
                    : 'bg-slate-100/50 border-slate-200 opacity-70'
                  : isDark
                  ? 'bg-slate-900/60 border-slate-800 hover:border-amber-500/40'
                  : 'bg-white border-slate-200 shadow-sm hover:border-amber-400'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-slate-800/80 flex items-center justify-center">
                      {getPlatformIcon(task.platform)}
                    </div>
                    <span className="text-xs font-bold text-slate-300">{task.platform}</span>
                  </div>

                  <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    +Rs {task.rewardRs.toFixed(2)}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 line-clamp-1 mb-1">{task.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4">
                  {task.description}
                </p>

                <div className="flex items-center gap-3 text-[11px] text-slate-500 mb-4">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {task.minDwellSeconds}s dwell
                  </span>
                  <span>•</span>
                  <span>{task.completionsCount} completed</span>
                </div>
              </div>

              {task.isCompletedByUser ? (
                <div className="w-full py-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 font-bold text-xs flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Reward Claimed
                </div>
              ) : (
                <button
                  id={`open-task-btn-${task.id}`}
                  onClick={() => handleOpenTask(task)}
                  className="w-full py-2.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-sm hover:opacity-95 transition-opacity flex items-center justify-center gap-2 text-xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Open Task & Earn Rs {task.rewardRs}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Task Verification Modal */}
      {activeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div
            className={`w-full max-w-lg p-6 sm:p-8 rounded-3xl border shadow-2xl space-y-5 ${
              isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {activeTask.platform} Verification
                </span>
                <h3 className="text-lg font-bold text-slate-100 mt-1">{activeTask.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Reward: Rs {activeTask.rewardRs.toFixed(2)}</p>
              </div>

              <div className="text-right">
                <div className="w-12 h-12 rounded-full border-2 border-amber-400/40 flex items-center justify-center font-mono font-bold text-amber-400 text-sm">
                  {timerRemaining > 0 ? `${timerRemaining}s` : <CheckCircle2 className="w-6 h-6 text-emerald-400" />}
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-800 bg-slate-950/50 text-xs text-slate-300 space-y-1">
              <p className="font-semibold text-slate-200">Verification Steps:</p>
              <ol className="list-decimal pl-4 space-y-1 text-slate-400 text-[11px]">
                <li>Task destination opened in a new tab: <span className="font-mono text-amber-400">{activeTask.destinationUrl}</span></li>
                <li>Remain on the page until the verification timer reaches 0s.</li>
                {activeTask.requiresProof && <li>Enter your account handle / profile username below.</li>}
              </ol>
            </div>

            {activeTask.requiresProof && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {activeTask.proofPrompt || 'Enter your handle or username for verification:'}
                </label>
                <input
                  id="task-proof-input"
                  type="text"
                  required
                  value={proofText}
                  onChange={(e) => setProofText(e.target.value)}
                  placeholder="@your_username"
                  className={`w-full px-3.5 py-2.5 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-amber-500/50 ${
                    isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>
            )}

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveTask(null)}
                className={`w-1/3 py-2.5 rounded-xl text-xs font-semibold border ${
                  isDark ? 'border-slate-800 text-slate-400 hover:bg-slate-800' : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Cancel
              </button>

              <button
                id="claim-task-reward-btn"
                type="button"
                disabled={!timerCompleted || submitting}
                onClick={handleClaimReward}
                className="w-2/3 py-2.5 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-md shadow-amber-500/20 hover:opacity-95 transition-opacity disabled:opacity-40 text-xs flex items-center justify-center gap-2"
              >
                {submitting ? 'Verifying...' : timerRemaining > 0 ? `Wait ${timerRemaining}s to claim` : `Claim Rs ${activeTask.rewardRs.toFixed(2)}`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
