import React from 'react';
import { useAuth } from '../context/AuthContext';
import { AlertCircle, Home, LayoutDashboard, ArrowLeft } from 'lucide-react';

interface NotFoundPageProps {
  onNavigate: (path: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigate }) => {
  const { user, theme } = useAuth();
  const isDark = theme === 'dark';

  return (
    <div
      id="not-found-page"
      className="min-h-[calc(100vh-14rem)] flex items-center justify-center px-4 py-16"
    >
      <div
        className={`w-full max-w-lg p-8 sm:p-10 rounded-3xl border shadow-2xl text-center relative overflow-hidden ${
          isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="w-8 h-8" />
        </div>

        <span className="text-xs font-black tracking-widest uppercase px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
          404 Error
        </span>

        <h1 className="text-3xl sm:text-4xl font-black mt-4 mb-2 text-slate-100">
          Page Not Found
        </h1>

        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-8 leading-relaxed">
          The page or route you are looking for does not exist or has been moved. All active tasks, surveys, and wallet earnings are safe.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          {user ? (
            <button
              id="not-found-dashboard-btn"
              onClick={() => onNavigate('/dashboard')}
              className="w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-lg shadow-amber-500/20 hover:opacity-95 transition-opacity flex items-center justify-center gap-2 text-xs"
            >
              <LayoutDashboard className="w-4 h-4" /> Go to Dashboard
            </button>
          ) : (
            <button
              id="not-found-home-btn"
              onClick={() => onNavigate('/')}
              className="w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-emerald-400 shadow-lg shadow-amber-500/20 hover:opacity-95 transition-opacity flex items-center justify-center gap-2 text-xs"
            >
              <Home className="w-4 h-4" /> Return to Homepage
            </button>
          )}

          <button
            id="not-found-back-btn"
            onClick={() => window.history.back()}
            className="w-full sm:w-auto px-5 py-3 rounded-xl font-semibold border border-slate-700 hover:bg-slate-800 text-slate-300 transition-colors flex items-center justify-center gap-2 text-xs"
          >
            <ArrowLeft className="w-4 h-4" /> Go Back
          </button>
        </div>
      </div>
    </div>
  );
};
